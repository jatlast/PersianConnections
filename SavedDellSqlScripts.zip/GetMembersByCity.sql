select contact_info.city as 'city'
	, count(login_info.user_name) as 'count'
from login_info
	, contact_info
where login_info.user_name = contact_info.user_name
and login_info.user_name != 'joe'
and login_info.user_name != 'persianconnections'
and login_info.user_name != 'connectionsadmin'
and login_info.user_name != 'jp'
group by contact_info.city
order by count desc
