if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LogIn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[LogIn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_DeleteAllDanglingUserNames]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_DeleteAllDanglingUserNames]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_DeleteEntireProfileByUserName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_DeleteEntireProfileByUserName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_FindDuplicates]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_FindDuplicates]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_FreeFormAudit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_FreeFormAudit]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GetDanglingUserNames]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GetDanglingUserNames]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GetIndividualTableInfoByUserName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GetIndividualTableInfoByUserName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GraphHourlyCreationDateStatsByDayMonthYear]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GraphHourlyCreationDateStatsByDayMonthYear]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GraphMonthlyCreationDateStatsByMonthYear]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GraphMonthlyCreationDateStatsByMonthYear]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GraphMonthlyCreationDateStatsByYear]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GraphMonthlyCreationDateStatsByYear]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_GraphYearlyCreationDateStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_GraphYearlyCreationDateStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[admin_TransactionsLogAudit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[admin_TransactionsLogAudit]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[advancedSearch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[advancedSearch]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[automatedCreateLoginInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[automatedCreateLoginInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[automatedFixLoginInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[automatedFixLoginInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[batchNightlyTransactionSend]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[batchNightlyTransactionSend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[cancel_paying_membership]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[cancel_paying_membership]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[checkUsernamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[checkUsernamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[createLoginInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[createLoginInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[deleteMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[deleteMail]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[deleteUserFromAllTables]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[deleteUserFromAllTables]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genBookMarks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genBookMarks]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genInbox]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genInbox]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genMemberHome]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genMemberHome]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genOutbox]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genOutbox]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genPicUpload]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genPicUpload]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[genSendMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[genSendMail]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getAboutInfoByNamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getAboutInfoByNamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getBillingInfoByNamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getBillingInfoByNamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getContactInfoByNamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getContactInfoByNamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getEmailByUserName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getEmailByUserName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getLoginInfoByEmailMaidenName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getLoginInfoByEmailMaidenName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getLoginInfoByNamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getLoginInfoByNamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getLoginInfoByUserNameMaidenName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getLoginInfoByUserNameMaidenName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getPersonalInfoByNamePassword]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[getPersonalInfoByNamePassword]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[hideUnhideProfile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[hideUnhideProfile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[insert_membership_cancellation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[insert_membership_cancellation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[mailSend]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[mailSend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[mailSendNewUserWelcome]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[mailSendNewUserWelcome]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[massMail_FindDuplicates]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[massMail_FindDuplicates]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[massMail_GetAllUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[massMail_GetAllUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[massMail_GetUsersWithUnreadMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[massMail_GetUsersWithUnreadMail]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[readReceivedMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[readReceivedMail]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[readSentMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[readSentMail]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[simpleSearch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[simpleSearch]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[singleProfile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[singleProfile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[transaction_credit_card_receive]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[transaction_credit_card_receive]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[transaction_credit_card_send]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[transaction_credit_card_send]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updateAboutInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updateAboutInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updateBillingInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updateBillingInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updateBookMarks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updateBookMarks]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updateContactInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updateContactInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updateLoginInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updateLoginInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updatePersonalInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updatePersonalInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[updatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[updatePicture]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [LogIn]
	@UserName varchar(32)
	, @Password varchar (16)
 AS

DECLARE @last_login datetime

/* Set the default values */
select @last_login = getdate()

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	update login_info 
		set last_login = @last_login
		where user_name = @UserName
	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_DeleteAllDanglingUserNames]

 AS

CREATE TABLE #DanglingUserNames( user_name VARCHAR(32) COLLATE database_default NOT NULL )
CREATE TABLE #IndividualUserNames( user_name VARCHAR(32) COLLATE database_default NOT NULL )

---------------- login_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from login_info 
	where user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- contact_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from contact_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- personal_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from personal_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- about_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from about_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- relationship ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from relationship 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
select user_name from #IndividualUserNames 
	where user_name not in (select user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- pictures ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from pictures 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

---------------- sent_from ----------------------------------------------
INSERT #IndividualUserNames
	select sent_from from mail 
		where sent_from not in (select user_name from login_info)
		or sent_from not in (select user_name from contact_info)
		or sent_from not in (select user_name from personal_info)
		or sent_from not in (select user_name from about_info)
		or sent_from not in (select user_name from relationship)
		or sent_from not in (select user_name from pictures)
	group by sent_from

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- sent_to ----------------------------------------------
INSERT #IndividualUserNames
	select sent_to from mail 
		where sent_to not in (select user_name from login_info)
		or sent_to not in (select user_name from contact_info)
		or sent_to not in (select user_name from personal_info)
		or sent_to not in (select user_name from about_info)
		or sent_to not in (select user_name from relationship)
		or sent_to not in (select user_name from pictures)
	group by sent_to

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

-- Drop both the tempory tables
drop table #IndividualUserNames

-- delete dangling profiles found using the login_info table...
PRINT 'Deleting dangling user_names found while running the stored procedure admin_GetDanglingUserNames'
DECLARE @UserName VARCHAR(32)
WHILE ( SELECT COUNT(*) FROM #DanglingUserNames ) > 370
BEGIN
	SELECT @UserName = (SELECT MAX(user_name) FROM #DanglingUserNames )
	PRINT 'Deleting User Name = (' + @UserName + ') based on stored procedure admin_GetDanglingUserNames'
	EXEC admin_DeleteEntireProfileByUserName @UserName
	PRINT 'Deleting User Name = (' + @UserName + ') from temp table'
	DELETE #DanglingUserNames WHERE user_name = @UserName
END

-- Drop the tempory table...
drop table #DanglingUserNames
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_DeleteEntireProfileByUserName]
 @UserName varchar(32)

 AS

-- Determine if the user_name exists in the login_info  table
IF EXISTS (SELECT user_name FROM login_info WHERE user_name = @UserName)
BEGIN
	-- If the user_name exists delete the login_info for that user
	print 'Delete login_info'
	delete login_info 
		where user_name = @UserName
END
ELSE
	BEGIN
		-- print that the login_table was not changed
		PRINT 'user_name does not exist in the login_info table'
	END


-- Determine if the user_name exists in the contact_info  table
IF EXISTS (SELECT user_name FROM contact_info WHERE user_name = @UserName)
BEGIN
	-- If the user_name exists delete the contact_info for that user
	print 'Delete contact_Info'
	delete contact_info 
		where user_name = @UserName
END
ELSE
	BEGIN
		-- print that the contact_table was not changed
		PRINT 'user_name does not exist in the contact_Info table'
	END

-- Determine if the user_name exists in the personal_info  table
IF EXISTS (SELECT user_name FROM personal_info WHERE user_name = @UserName)
BEGIN
	-- If the user_name exists delete the personal_info for that user
	print 'Delete personal_info'
	delete personal_info 
		where user_name = @UserName
END
ELSE
	BEGIN
		-- print that the personal_info was not changed
		PRINT 'user_name does not exist in the personal_info table'
	END

-- Determine if the user_name exists in the about_info  table
IF EXISTS (SELECT user_name FROM about_info WHERE user_name = @UserName)
BEGIN
	-- If the user_name exists delete the about_info for that user
	print 'Delete about_info'
	delete about_info 
		where user_name = @UserName
END
ELSE
	BEGIN
		-- print that the about_info was not changed
		PRINT 'user_name does not exist in the about_info table'
	END

-- Determine if the user_name exists in the relationship  table
IF EXISTS (SELECT user_name FROM relationship WHERE user_name = @UserName)
BEGIN
	-- If the relationship exists delete the about_info for that user
	print 'Delete relationship'
	delete relationship 
		where user_name = @UserName
END
ELSE
	BEGIN
		-- print that the relationship was not changed
		PRINT 'user_name does not exist in the relationship table'
	END

-- Determine if the user_name exists in the pictures  table
IF EXISTS (SELECT user_name FROM pictures WHERE user_name = @UserName)
BEGIN
	-- If the user_name exists delete the pictures for that user
	print 'Delete pictures'
	delete pictures 
		where user_name = @UserName
END
ELSE
	BEGIN
		--print that the pictures was not changed
		PRINT 'user_name does not exist in the pictures table'
	END

-- Determine if the user_name exists in the mail  table
IF EXISTS (SELECT sent_to FROM mail WHERE sent_to = @UserName)
	BEGIN
		-- If the user_name exists delete the user from the pictures table 
		PRINT 'Deleting user from mail using sent_to'
		DELETE mail 
		WHERE sent_to = @UserName
	END
ELSE
	BEGIN
		-- If the user_name is not unique exit with a return value of 666 
		PRINT 'user had no sent_to mail'
	END

-- Determine if the user_name exists in the mail  table
IF EXISTS (SELECT sent_from FROM mail WHERE sent_from = @UserName)
	BEGIN
		-- If the user_name exists delete the user from the pictures table 
		PRINT 'Deleting user from mail using sent_from'
		DELETE mail 
		WHERE sent_from = @UserName
	END
ELSE
	BEGIN
		-- If the user_name is not unique exit with a return value of 666 
		PRINT 'user had no sent_from mail'
	END

-- Determine if the user_name exists in the email  table
IF EXISTS (SELECT user_name FROM book_marks WHERE user_name = @UserName OR  book_mark = @UserName)
	BEGIN
		-- If the user_name exists delete the user from the pictures table 
		PRINT 'Deleting user from book_marks'
		DELETE book_marks 
		WHERE user_name = @UserName
		OR book_mark = @UserName
	END
ELSE
	BEGIN
		-- If the user_name is not unique exit with a return value of 666 
		PRINT 'user had no book_marks'
	END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_FindDuplicates]
 @DupToFind VARCHAR(64) 		= 'email'
, @TableWithDup VARCHAR(64) 	= 'login_info'
, @OrderBy VARCHAR(26)		= 'login_info.user_name'
, @AscDesc VARCHAR(4)		= 'ASC'
, @Limit INT				= 100
, @Index VARCHAR(6)			= '1'
, @UserName VARCHAR(32)		= '%'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT 'Order by ' + @TableWithDup + '.' + @DupToFind + ', ' + @OrderBy  + ' ' + @AscDesc

DECLARE @RowCount INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 1 )

SET ROWCOUNT @RowCount

-- count the total number of rows in the login_info table...
EXEC ( 'SELECT ' + @DupToFind + '
		INTO #dups FROM  ' + @TableWithDup + '
		GROUP BY ' + @DupToFind + '
		HAVING COUNT(*) > 1

SELECT COUNT(*) AS "count"
	FROM ' + @TableWithDup +'
		, #dups
	WHERE ' + @TableWithDup + '.' + @DupToFind + ' = #dups.' + @DupToFind + '


SELECT login_info.user_name		AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, sex.choice			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.first_name		AS "first_name"
		, contact_info.last_name		AS "last_name"
		, contact_info.street_address	AS "street_address"
		, contact_info.city		AS "city"
		, state.choice			AS "state"
		, country.choice			AS "country"
		, contact_info.zip		AS "zip"
		, contact_info.telephone		AS "telephone"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
		, sex
		, state
		, country
		, #dups
	WHERE ' + @TableWithDup + '.' + @DupToFind + ' = #dups.' + @DupToFind + '
		AND login_info.user_name LIKE ''' + @UserName + '''
		AND login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
		AND login_info.sex = sex.value
		AND contact_info.state = state.value
		AND contact_info.country = country.value
	ORDER BY  ' + @TableWithDup  + '.' + @DupToFind  + ' ' + @AscDesc + ', ' + @OrderBy  + ' ' + @AscDesc
) -- end EXEC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_FreeFormAudit]
@OrderBy CHAR(26)		= 'login_info.creation_date'
, @AscDesc CHAR(4)		= 'DESC'
, @Limit INT			= 100
, @Index CHAR(6)		= '1'
, @UserName VARCHAR(32)	= '%'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT 'Order by ' + @OrderBy  + @AscDesc

-- If UserName != "%" the user entered data to search for 
IF (@UserName != "%")
BEGIN
	PRINT 'user entered a user_name'
	-- Pad with SQL wildcards for searching 
	SELECT @UserName = ( SELECT ( @UserName + '%') )
END

PRINT 'user_name = ' + @UserName

DECLARE @RowCount INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 1 )

-- count the total number of rows in the login_info table...
SELECT COUNT(*) AS "count"
	FROM login_info

SET ROWCOUNT @RowCount

PRINT 'SQL:  SELECT login_info.user_name		AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, login_info.sex			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.last_name		AS "last_name"
		, contact_info.city		AS "city"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
	WHERE login_info.user_name LIKE ''' + @UserName + '''
		AND login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
	ORDER BY ' + @OrderBy + @AscDesc

EXEC ('SELECT login_info.user_name		AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, login_info.sex			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.last_name		AS "last_name"
		, contact_info.city		AS "city"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
	WHERE login_info.user_name LIKE ''' + @UserName + '''
		AND login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
	ORDER BY ' + @OrderBy + @AscDesc
) -- end EXEC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GetDanglingUserNames]

 AS
CREATE TABLE #DanglingUserNames( user_name VARCHAR(32) COLLATE database_default NOT NULL )
CREATE TABLE #IndividualUserNames( user_name VARCHAR(32) COLLATE database_default NOT NULL )

---------------- login_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from login_info 
	where user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- contact_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from contact_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- personal_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from personal_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- about_info ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from about_info 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from relationship)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- relationship ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from relationship 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from pictures)

INSERT #DanglingUserNames
select user_name from #IndividualUserNames 
	where user_name not in (select user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- pictures ----------------------------------------------
INSERT #IndividualUserNames
SELECT user_name from pictures 
	where user_name not in (SELECT user_name from login_info)
		or user_name not in (SELECT user_name from contact_info)
		or user_name not in (SELECT user_name from personal_info)
		or user_name not in (SELECT user_name from about_info)
		or user_name not in (SELECT user_name from relationship)

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

---------------- sent_from ----------------------------------------------
INSERT #IndividualUserNames
	select sent_from from mail 
		where sent_from not in (select user_name from login_info)
		or sent_from not in (select user_name from contact_info)
		or sent_from not in (select user_name from personal_info)
		or sent_from not in (select user_name from about_info)
		or sent_from not in (select user_name from relationship)
		or sent_from not in (select user_name from pictures)
	group by sent_from

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)

delete #IndividualUserNames

---------------- sent_to ----------------------------------------------
INSERT #IndividualUserNames
	select sent_to from mail 
		where sent_to not in (select user_name from login_info)
		or sent_to not in (select user_name from contact_info)
		or sent_to not in (select user_name from personal_info)
		or sent_to not in (select user_name from about_info)
		or sent_to not in (select user_name from relationship)
		or sent_to not in (select user_name from pictures)
	group by sent_to

INSERT #DanglingUserNames
SELECT user_name from #IndividualUserNames 
	where user_name not in (SELECT user_name from #DanglingUserNames)


-- Return the number of dangling user_names...
SELECT count(*) AS 'count'
FROM #DanglingUserNames

-- Return the actual dangling user_names...
SELECT user_name FROM #DanglingUserNames
ORDER BY user_name

-- Drop both the tempory tables
drop table #IndividualUserNames
drop table #DanglingUserNames
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GetIndividualTableInfoByUserName]
 @UserName varchar(32) = 'PersianConnections'

 AS

----------------------- login_info ---------------------------
print 'get text info from login_info table'
select	user_id
	, user_name
	, membership_type
	, password
	, password_hint
	, email
	, sex.choice as 'sex'
	, creation_date
	, last_login
	, photo_submitted
from login_info
	, sex
where user_name = @UserName
	and login_info.sex = sex.value

----------------------- contact_info ---------------------------
print 'get text info from contact_info table'
select contact_info.user_name
		, contact_info.first_name
		, contact_info.last_name
		, contact_info.street_address
		, contact_info.city
		, state.choice as 'state'
		, country.choice as 'country'
		, contact_info.zip
		, contact_info.telephone
from contact_info
	, state
	, country
where user_name = @UserName
	and contact_info.state = state.value 
	and contact_info.country = country.value 

----------------------- personal_info ---------------------------
print 'get text info from personal_info table'
select personal_info.user_name 
		, sex_preference.choice as 'sex_preference'
	, personal_info.age as 'age'
	, marital_status.choice as 'marital_status'
	, profession.choice as 'profession'
	, education.choice as 'education'
	, religion.choice as 'religion'
	, height.choice as 'height'
		, weight.choice  as 'weight'
	, eyes.choice as 'eyes'
	, hair.choice as 'hair'
	, personal_info.min_age_desired
	, personal_info.max_age_desired
	, cook.choice as 'cook'
	, smoke.choice as 'smoke'
	, drink.choice as 'drink'
	, party.choice as 'party'
	, political.choice as 'political'
	, housing_status.choice as 'housing_status'

from personal_info
	, sex_preference
	, marital_status
	, profession
	, education
	, religion
	, height
	, weight
	, eyes
	, hair
	, cook
	, smoke
	, drink
	, party
	, political
	, housing_status
where personal_info.user_name = @UserName
	and personal_info.sex_preference = sex_preference.value
	and personal_info.marital_status = marital_status.value
	and personal_info.profession = profession.value
	and personal_info.education = education.value
	and personal_info.religion = religion.value
	and personal_info.height = height.value
	and personal_info.weight = weight.value
	and personal_info.eyes = eyes.value
	and personal_info.hair = hair.value
	and personal_info.cook = cook.value
	and personal_info.smoke = smoke.value
	and personal_info.drink = drink.value
	and personal_info.party = party.value
	and personal_info.political = political.value
	and personal_info.housing_status = housing_status.value

----------------------- about_info ---------------------------
print 'get info from about_info table'
select user_name
	, screen_quote
	, about_yourself
	, questionable
from about_info
where user_name = @UserName

----------------------- relationship ---------------------------
print 'get text info from relationship table'
select user_name
	,  prefer_not_to_say 
	, any_relationship
	, hang_out 
	, short_term 
	, long_term 
	, talk_email
	, photo_exchange
	, marriage
	, other
from relationship
where user_name = @UserName

----------------------- pictures ---------------------------
print 'get info from pictures table'
SELECT user_name
	, photo_1
	, photo_2
	, photo_3
	, photo_4
	, photo_5
FROM pictures 
where user_name = @UserName

----------------------- mail ---------------------------
print 'get info from mail table'
SELECT mail_id
	, sent_to
	, sent_from
	, subject
	, message_text
	, when_sent
	, when_read
	, sender_deleted
	, receiver_deleted
FROM mail 
where sent_to = @UserName 
	or sent_from = @UserName

----------------------- book_marks ---------------------------
print 'get info from book_marks table'
SELECT user_name
	, book_mark
FROM book_marks
WHERE user_name = @UserName
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GraphHourlyCreationDateStatsByDayMonthYear]
@Day char(2) = '1'
 , @Month char(2) = ''
,  @Year char(4) = '2001'

 AS

-- Declare a variable to hold the month to get results from...
declare @SearchDay datetime

-- Set the current search date to the most recent creation_date 
-- if the procedure was called without parameters...
if(@Month = '')
	begin
		select @SearchDay = ( select max(creation_date) from login_info )
	end
ELSE
	begin
		select @SearchDay = @Month + '-' + @Day + '-' + @Year
	end

-- Print all month variables for debugging...
print 'SearchDay = '  + convert(char(25), @SearchDay , 113)

-- Populate a temporary table with only the search month's data...
select datepart( hour, creation_date ) as 'creation_hour'
	, count(*) as 'new_members'
INTO #CreationDay
from login_info
where datepart( day, creation_date ) = datepart(day, @SearchDay)
and datepart( month, creation_date ) = datepart(month, @SearchDay)
and datepart( year, creation_date ) = datepart(year, @SearchDay)
and datepart( hour, creation_date ) < 24
group by datepart( hour, creation_date )

---------------------------------------------------------
-- Return the maximum number of days in the search month
-- So the DB takes care of figuring out leap year crap
---------------------------------------------------------
declare @TempSearchDay datetime
-- First: set the @Day variable to 1 and the rest equal to the current search date
-- and reset the current month search to those fields (last day of that month and year)...
select @Day = '1'
select @Month = datepart(month, @SearchDay)
select @Year = datepart(year, @SearchDay)
-- Declare a variable to represent the last day of the search month/day/year...
select @TempSearchDay = @Month + '-' + @Day + '-' + @Year
-- Second: Add a month so we are on the first of next month...
select @TempSearchDay = dateadd(month, 1, @TempSearchDay)
-- Third: Subtract a single day to return the last day of the search month...
select @TempSearchDay = dateadd(day, -1, @TempSearchDay)
-- Finally: Select the day...
select datepart( day, @TempSearchDay ) as 'days_in_month'
print 'SearchDay = ' + convert(char(10), @TempSearchDay, 101)
-----------------------------------------------------------------------


-- Return the search_month and search_year
select datepart(day, @SearchDay) as 'search_day'
	, datepart(month, @SearchDay) as 'search_month'
	, datepart(year, @SearchDay) as 'search_year'

-- Return the Weekday name and number as well as the number of new members for that day...
select creation_hour as 'hour'
	, new_members
 from #CreationDay
order by creation_hour

-- Drop the temporary table
drop table #CreationDay
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GraphMonthlyCreationDateStatsByMonthYear]
@Day char(1) = '1'
 , @Month char(3) = '1'
,  @Year char(4) = '1999'

 AS

-- Declare a variable to hold the month to get results from...
declare @SearchMonth datetime

-- Set the current search date to the most recent creation_date 
-- if the procedure was called without parameters...
if(@Year = '1999')
	begin
		select @SearchMonth = ( select max(creation_date) from login_info )
	end
ELSE
	begin
		select @SearchMonth = @Month + '-' + @Day + '-' + @Year
	end

-- Declare a variable to represent the precious month to limith the lower bound of the selections...
declare @PreviousMonth datetime
-- Subtract one month from the search month to initialize the PreviousMonth
select @PreviousMonth = dateadd(month, -1, @SearchMonth)

-- Declare a variable to represent the next month to limith the upper bound of the selections...
declare @NextMonth datetime
-- Add one month to the search month to initialize the NextMonth
select @NextMonth = dateadd(month, 1, @SearchMonth)

-- Print all month variables for debugging...
print 'PreviousMonth	= ' + convert(char(10), @PreviousMonth, 101)
print 'SearchMonth	= ' + convert(char(10), @SearchMonth, 101)
print 'NextMonth	= ' + convert(char(10), @NextMonth	, 101)

-- Populate a temporary table with only the search month's data...
select convert(char(10), creation_date, 101) as 'creation_date'
	, count(*) as 'new_members'
INTO #CreationDate
from login_info
where datepart( month, creation_date ) < datepart(month, @NextMonth)
and datepart( month, creation_date ) > datepart(month, @PreviousMonth)
group by convert(char(10), creation_date, 101)


---------------------------------------------------------
-- Return the maximum number of days in the search month
-- So the DB takes care of figuring out leap year crap
---------------------------------------------------------
-- First: set the @Day variable to 1 and the rest equal to the current search date
-- and reset the current month search to those fields (last day of that month and year)...
select @Day = '1'
select @Month = datepart(month, @SearchMonth)
select @Year = datepart(year, @SearchMonth)
-- Declare a variable to represent the last day of the search month/day/year...
select @SearchMonth = @Month + '-' + @Day + '-' + @Year
-- Second: Add a month so we are on the first of next month...
select @SearchMonth = dateadd(month, 1, @SearchMonth)
-- Third: Subtract a single day to return the last day of the search month...
select @SearchMonth = dateadd(day, -1, @SearchMonth)
-- Finally: Select the day...
select datepart( day, @SearchMonth ) as 'days_in_month'
print 'SearchMonth = ' 	+ convert(char(10), @SearchMonth, 101)
-----------------------------------------------------------------------

-- Return the search_month and search_year
select datepart(month, @SearchMonth) as 'search_month'
	, datepart(year, @SearchMonth) as 'search_year'

-- Return the Weekday name and number as well as the number of new members for that day...
select datename(weekday, creation_date) as 'week_day'
	, datepart(day, creation_date) as 'day_number'
	, new_members
 from #CreationDate
order by creation_date

-- Drop the temporary table
drop table #CreationDate
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GraphMonthlyCreationDateStatsByYear]
@Year char(4) = ''

 AS

-- Declare a variable to hold the month to get results from...
declare @SearchYear datetime

-- Set the current search date to the most recent creation_date 
-- if the procedure was called without parameters...
if(@Year = '')
	begin
		select @SearchYear = ( select max(creation_date) from login_info )
	end
ELSE
	begin
		select @SearchYear = '1-1-' + @Year
	end

-- Declare a variable to represent the precious month to limith the lower bound of the selections...
-- Print all month variables for debugging...
print 'SearchYear = ' + convert(char(10), datepart(year, @SearchYear), 101)

-- Populate a temporary table with only the search month's data...
select datepart( month, creation_date ) as 'creation_month'
	, count(*) as 'new_members'
INTO #CreationDate
from login_info
where datepart( year, creation_date ) = datepart( year, @SearchYear )
group by datepart( month, creation_date )

-- Return the search_month and search_year
select datepart(year, @SearchYear) as 'search_year'

-- Return the Weekday name and number as well as the number of new members for that day...
select creation_month as 'creation_month'
	, new_members
 from #CreationDate
order by creation_month

-- Drop the temporary table
drop table #CreationDate
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_GraphYearlyCreationDateStats]
 AS

-- Populate a temporary table with only the search month's data...
select datepart( year, creation_date ) as 'creation_year'
	, count(*) as 'new_members'
INTO #CreationDate
from login_info
group by datepart( year, creation_date )

--select distinct(creation_year) as 'distinct_years' 
--from #CreationDate

-- Return the Weekday name and number as well as the number of new members for that day...
select creation_year as 'creation_year'
	, new_members
 from #CreationDate
order by creation_year

-- Drop the temporary table
drop table #CreationDate
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [admin_TransactionsLogAudit]
@OrderBy CHAR(64)		= 'transactions_log.date_of_this_transaction'
, @AscDesc CHAR(4)		= 'DESC'
, @Limit INT			= 100
, @Index CHAR(6)		= '1'
, @UserName VARCHAR(32)	= '%'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT 'Order by ' + @OrderBy  + @AscDesc

-- If UserName != "%" the user entered data to search for 
IF (@UserName != "%")
BEGIN
	PRINT 'user entered a user_name'
	-- Pad with SQL wildcards for searching 
	SELECT @UserName = ( SELECT ( @UserName + '%') )
END

PRINT 'user_name = ' + @UserName

DECLARE @RowCount INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 1 )

-- count the total number of rows in the login_info table...
SELECT COUNT(*) AS "count"
	FROM transactions_log

SET ROWCOUNT @RowCount

EXEC ( 'SQL:  SELECT transactions_log.*
			, login_info.password
	FROM transactions_log
		, login_info
	WHERE transactions_log.user_name LIKE ''' + @UserName + '''
		AND transactions_log.user_name = login_info.user_name
	ORDER BY ' + @OrderBy + @AscDesc
) -- end EXEC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [advancedSearch]
@Search INT
, @IAm CHAR
, @Seeking CHAR
, @MaritalStatus VARCHAR(2)
, @City VARCHAR(32)
, @State VARCHAR(2)
, @Country VARCHAR(3)
, @Profession VARCHAR(2)
, @Education VARCHAR(2)
, @Religion VARCHAR(2)
, @MinAgeDesired VARCHAR(2)
, @MaxAgeDesired VARCHAR(2)
, @MinHeight VARCHAR(2)
, @MaxHeight VARCHAR(2)
, @MinWeight VARCHAR(2)
, @MaxWeight VARCHAR(2)
, @Eyes VARCHAR(2)
, @Hair VARCHAR(2)
, @Cook VARCHAR(2)
, @Smoke VARCHAR(2)
, @Drink VARCHAR(2)
, @Party VARCHAR(2)
, @Political VARCHAR(2)
, @HousingStatus VARCHAR(2)
, @Relationship VARCHAR(2)
, @TextSearch VARCHAR(64)
, @WhichFields VARCHAR(2)
, @Limit INT
, @Sort VARCHAR(16)
, @Index VARCHAR(6)
, @UserName VARCHAR(32)

 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserName, 'allow_search_advanced'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

declare @GlobalRowCount INT
SELECT @GlobalRowCount = 100;

declare @AlternativeMin INT
declare @AlternativeMax INT

-- hold the relationship types
declare @prefer_not_to_say CHAR
declare @any_relationship CHAR
declare @hang_out CHAR
declare @short_term CHAR
declare @long_term CHAR
declare @talk_email CHAR
declare @photo_exchange CHAR
declare @marriage CHAR
declare @other CHAR

-- set all relationship types to a non existant value
SELECT @prefer_not_to_say = 9
SELECT @any_relationship = 9
SELECT @hang_out = 9
SELECT @short_term = 9
SELECT @long_term = 9
SELECT @talk_email = 9
SELECT @photo_exchange = 9
SELECT @marriage = 9
SELECT @other = 9


IF (@IAm = @Seeking AND @IAm > "0")
BEGIN
	-- If the user is searching same sex set Alternative to true 
	PRINT 'same sex search'
	SELECT @AlternativeMin = 2
	SELECT @AlternativeMax = 4
END
else
BEGIN
	-- If the user is searching opposite sex OR all set Alternative to false 
	PRINT 'opposite sex search'
	SELECT @AlternativeMin = 0
	SELECT @AlternativeMax = 1
END

-- If MaritalStatus = 0 user is searching all types of status 
IF (@MaritalStatus = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @MaritalStatus = '%'
END

	-- If City != "" the user entered data to search for 
IF (@City != "")
BEGIN
	-- Pad with SQL wildcards for searching 
	SELECT @City = ( SELECT ('%' + @City + '%') )
END
	-- If City = "" the user did not narrow the search by city 
IF (@City = "")
BEGIN
	-- add an SQL wildcard for searching 
	SELECT @City = '%'
END
	-- If State = 0 the user did not narrow the search by state 
IF (@State = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @State = '%'
END

	-- If Country = 0 the user did not narrow the search by country 
IF (@Country = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Country = '%'
END

-- If Profession = 0 the user did not narrow the search by profession 
IF (@Profession = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Profession = '%'
END

-- If Education = 0 the user did not narrow the search by education 
IF (@Education = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Education = '%'
END

-- If Religion = 0 the user did not narrow the search by religion 
IF (@Religion = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Religion = '%'
END

-- If Eyes = 0 the user did not narrow the search by eye color 
IF (@Eyes = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Eyes = '%'
END

-- If Hair = 0 the user did not narrow the search by hair color 
IF (@Hair = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Hair = '%'
END

-- If Cook = 0 the user did not narrow the search by cooking abilities 
IF (@Cook = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Cook = '%'
END

-- If Smoke = 0 the user did not narrow the search by smoking habits 
IF (@Smoke = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Smoke = '%'
END

-- If Drink = 0 the user did not narrow the search by Drinking habits 
IF (@Drink = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Drink = '%'
END

-- If Party = 0 the user did not narrow the search by the amount of partying 
IF (@Party = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Party = '%'
END

-- If Political = 0 the user did not narrow the search by political affiliation 
IF (@Political = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @Political = '%'
END

-- If HousingStatus = 0 the user did not narrow the search by housing status 
IF (@HousingStatus = "0")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @HousingStatus = '%'
END


--------------- Initialize the proper relationship types

IF (@Relationship = "1")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @prefer_not_to_say = 1

END

IF (@Relationship = "2")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @hang_out = 1

END

IF (@Relationship = "3")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @short_term = 1

END

IF (@Relationship = "4")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @long_term = 1

END

IF (@Relationship = "5")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @talk_email = 1

END

IF (@Relationship = "6")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @photo_exchange = 1

END

IF (@Relationship = "7")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @marriage = 1

END

IF (@Relationship = "8")
BEGIN
	-- use SQL wildcard when searching 
	SELECT @other = 1

END
------------------------------------------------

-- If TextSearch != "" the user entered a text string to search for 
IF (@TextSearch != "")
BEGIN
	-- Pad with SQL wildcard for searching 
	SELECT @TextSearch = ( SELECT ('%' + @TextSearch + '%') )
END

-- If TextSearch = "" the euser did not enter a text string to search for 
IF (@TextSearch = "")
BEGIN
	-- Add an SQL wildcard for searching 
	SELECT @TextSearch = '%' 
END

-- Determin how the user whats the results ordered...
DECLARE @OrderBy CHAR(32) 	-- Holds the order by clause condition
IF( @Sort = 'user_name' )
	BEGIN
		SELECT @OrderBy = 'contact_info.user_name'
	END
ELSE
	IF( @Sort = 'state' )
		BEGIN
			SELECT @OrderBy = 'contact_info.state'
		END
	ELSE
		IF( @Sort = 'age' )
		BEGIN
			SELECT @OrderBy = 'personal_info.age'
		END
		ELSE
			IF( @Sort = 'creation_date' )
			BEGIN
				SELECT @OrderBy = 'login_info.creation_date DESC'
			END

PRINT 'Order by ' + @OrderBy

DECLARE @RowCount	INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 2 )

-- the SET ROWCOUNT limits the number of rows affected
SET ROWCOUNT @GlobalRowCount


-- If WhichFields = 1 AND TextSearch != '%' the user is looking for a user_name
IF (@WhichFields = "1" AND @TextSearch != '%')
BEGIN
		PRINT 'Find a single user_name'
-- Start DO NOT limit search by relationship type
IF (@Relationship = 0)
BEGIN
	PRINT 'Any Relationship count'
	-- Select the raw information by joining just the personal_info and relationship tables... 
		SELECT CASE 
				WHEN COUNT(*) >= @GlobalRowCount THEN @GlobalRowCount
				ELSE COUNT(*)
			END 'Number of Rows 1'
		FROM login_info 
			, contact_info
			, personal_info
			, about_info
		WHERE login_info.user_name LIKE @TextSearch
		AND about_info.questionable = 0
		AND login_info.photo_submitted >= @Search
		AND login_info.sex LIKE @Seeking
		AND CONVERT (INT, personal_info.sex_preference) >= @AlternativeMin
		AND CONVERT (INT, personal_info.sex_preference) <= @AlternativeMax

		AND personal_info.marital_status LIKE @MaritalStatus
		AND contact_info.city LIKE @City
		AND contact_info.state LIKE @State
		AND contact_info.country LIKE @Country
		AND personal_info.profession LIKE @Profession
		AND personal_info.education LIKE @Education
		AND personal_info.religion LIKE @Religion

		AND CONVERT (INT, personal_info.age) >= @MinAgeDesired
		AND CONVERT (INT, personal_info.age) <= @MaxAgeDesired

		AND CONVERT (INT, personal_info.height) >= @MinHeight
		AND CONVERT (INT, personal_info.height) <= @MaxHeight
		AND CONVERT (INT, personal_info.weight) >= @MinWeight
		AND CONVERT (INT, personal_info.weight) <= @MaxWeight

		AND personal_info.eyes LIKE @Eyes
		AND personal_info.hair LIKE @Hair
		AND personal_info.cook LIKE @Cook
		AND personal_info.smoke LIKE @Smoke
		AND personal_info.drink LIKE @Drink
		AND personal_info.party LIKE @Party
		AND personal_info.political LIKE @Political		
		AND personal_info.housing_status LIKE @HousingStatus

		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = personal_info.user_name
		AND login_info.user_name = about_info.user_name

		PRINT 'Any Relationship Sort by ' + @OrderBy
		
SET ROWCOUNT @RowCount
		-- Select the raw information by joining just the personal_info and relationship tables... 
		EXEC ('SELECT login_info.user_name AS "user_name"
			, contact_info.city AS "city"
			, state.choice AS "state"
			, country.choice AS "country"
			, personal_info.age AS "age"
			, about_info.screen_quote AS "screen_quote"
			, about_info.about_yourself AS "about_yourself"
			, pictures.photo_1 AS "pic 1"

		FROM login_info
			, contact_info
			, personal_info
			, about_info
			, state
			, country
			, pictures
		WHERE login_info.user_name LIKE ''' + @TextSearch + '''
			AND login_info.photo_submitted >= ''' + @Search + '''
			AND login_info.user_name = contact_info.user_name
			AND login_info.user_name = personal_info.user_name
			AND login_info.user_name = about_info.user_name
			AND login_info.user_name = pictures.user_name
			AND contact_info.state = state.value
			AND contact_info.country = country.value
			AND personal_info.user_name IN 
			(
			SELECT login_info.user_name
				FROM login_info
					, contact_info
					, personal_info
					, about_info
				WHERE login_info.sex LIKE ''' + @Seeking + '''
				AND about_info.questionable = 0
				AND CONVERT (INT, personal_info.sex_preference) >= ''' + @AlternativeMin + '''
				AND CONVERT (INT, personal_info.sex_preference) <= ''' + @AlternativeMax + '''
	
				AND personal_info.marital_status LIKE ''' + @MaritalStatus + '''
				AND contact_info.city LIKE ''' + @City + '''
				AND contact_info.state LIKE ''' + @State + '''
				AND contact_info.country LIKE ''' + @Country + '''
				AND personal_info.profession LIKE ''' + @Profession + '''
				AND personal_info.education LIKE ''' + @Education + '''
				AND personal_info.religion LIKE ''' + @Religion + '''
		
				AND CONVERT (INT, personal_info.age) >= ''' + @MinAgeDesired + '''
				AND CONVERT (INT, personal_info.age) <= ''' + @MaxAgeDesired + '''
		
				AND CONVERT (INT, personal_info.height) >= ''' + @MinHeight + '''
				AND CONVERT (INT, personal_info.height) <= ''' + @MaxHeight + '''
				AND CONVERT (INT, personal_info.weight) >= ''' + @MinWeight + '''
				AND CONVERT (INT, personal_info.weight) <= ''' + @MaxWeight + '''

	
				AND personal_info.eyes LIKE ''' + @Eyes + '''
				AND personal_info.hair LIKE ''' + @Hair + '''
				AND personal_info.cook LIKE ''' + @Cook + '''
				AND personal_info.smoke LIKE ''' + @Smoke + '''
				AND personal_info.drink LIKE ''' + @Drink + '''
				AND personal_info.party LIKE ''' + @Party + '''
				AND personal_info.political LIKE ''' + @Political + '''
				AND personal_info.housing_status LIKE ''' + @HousingStatus + '''
		
				AND login_info.user_name = contact_info.user_name
				AND login_info.user_name = personal_info.user_name
				AND login_info.user_name = about_info.user_name
			)
	ORDER BY ' + @OrderBy
	) -- end EXEC
SET ROWCOUNT 0
		RETURN 1
END -- Relationship = 0 "Any"


-- Start Limit search by relationship type
IF (@Relationship != 0)
BEGIN
PRINT 'Limit Relationship Count'
-- Select the raw information by joining just the personal_info and relationship tables... 

SELECT CASE 
		WHEN COUNT(*) >= @GlobalRowCount THEN @GlobalRowCount
		ELSE COUNT(*)
	END 'Number of Rows 2'
	FROM relationship 
	WHERE relationship.user_name LIKE @TextSearch
		AND
		(
		relationship.prefer_not_to_say = @prefer_not_to_say	
		OR relationship.hang_out = @hang_out
		OR relationship.short_term = @short_term		
		OR relationship.long_term = @long_term				
		OR relationship.talk_email = @talk_email		
		OR relationship.photo_exchange = @photo_exchange		
		OR relationship.marriage = @marriage				
		OR relationship.other = @other
		)
		AND relationship.user_name IN 
		(
		SELECT login_info.user_name
			FROM login_info
				, contact_info
				, personal_info
				, about_info
			WHERE login_info.sex LIKE @Seeking
			AND about_info.questionable = 0
			AND login_info.photo_submitted >= @Search
			AND CONVERT (INT, personal_info.sex_preference) >= @AlternativeMin
			AND CONVERT (INT, personal_info.sex_preference) <= @AlternativeMax
			AND personal_info.marital_status LIKE @MaritalStatus
			AND contact_info.city LIKE @City
			AND contact_info.state LIKE @State
			AND contact_info.country LIKE @Country
			AND personal_info.profession LIKE @Profession
			AND personal_info.education LIKE @Education
			AND personal_info.religion LIKE @Religion
			AND CONVERT (INT, personal_info.age) >= @MinAgeDesired
			AND CONVERT (INT, personal_info.age) <= @MaxAgeDesired

			AND CONVERT (INT, personal_info.height) >= @MinHeight
			AND CONVERT (INT, personal_info.height) <= @MaxHeight
			AND CONVERT (INT, personal_info.weight) >= @MinWeight
			AND CONVERT (INT, personal_info.weight) <= @MaxWeight
			AND personal_info.eyes LIKE @Eyes
			AND personal_info.hair LIKE @Hair
			AND personal_info.cook LIKE @Cook
			AND personal_info.smoke LIKE @Smoke
			AND personal_info.drink LIKE @Drink
			AND personal_info.party LIKE @Party
			AND personal_info.political LIKE @Political
			AND personal_info.housing_status LIKE @HousingStatus
			AND login_info.user_name = contact_info.user_name
			AND login_info.user_name = personal_info.user_name
			AND login_info.user_name = about_info.user_name
			)

		PRINT 'Limit Relationship Sort by ' + @OrderBy

SET ROWCOUNT @RowCount
		-- Select the raw information by joining just the personal_info and relationship tables... 
		EXEC ('SELECT login_info.user_name AS "user_name"
			, contact_info.city AS "city"
			, state.choice AS "state"
			, country.choice AS "country"
			, personal_info.age AS "age"
			, about_info.screen_quote AS "screen_quote"
			, about_info.about_yourself AS "about_yourself"
			, pictures.photo_1 AS "pic 1"

		FROM login_info
			, contact_info
			, personal_info
			, about_info
			, state
			, country
			, pictures
		WHERE login_info.user_name LIKE ''' + @TextSearch + '''
			AND login_info.photo_submitted >= ''' + @Search + '''
			AND login_info.user_name = contact_info.user_name
			AND login_info.user_name = personal_info.user_name
			AND login_info.user_name = about_info.user_name
			AND login_info.user_name = pictures.user_name
			AND contact_info.state = state.value
			AND contact_info.country = country.value
			AND personal_info.user_name IN 
			(
			SELECT relationship.user_name
				FROM relationship 
			WHERE (
				relationship.prefer_not_to_say = ''' + @prefer_not_to_say + '''
				OR relationship.hang_out = ''' + @hang_out + '''
				OR relationship.short_term = ''' + @short_term + '''
				OR relationship.long_term = ''' + @long_term + '''
				OR relationship.talk_email = ''' + @talk_email + '''
				OR relationship.photo_exchange = ''' + @photo_exchange + '''
				OR relationship.marriage = ''' + @marriage + '''
				OR relationship.other = ''' + @other + '''
				)

			AND relationship.user_name IN 
					(
					SELECT login_info.user_name
						FROM login_info
							, contact_info
							, personal_info
							, about_info
						WHERE login_info.sex LIKE ''' + @Seeking + '''
						AND about_info.questionable = 0
						AND CONVERT (INT, personal_info.sex_preference) >= ''' + @AlternativeMin + '''
						AND CONVERT (INT, personal_info.sex_preference) <= ''' + @AlternativeMax + '''
						AND personal_info.marital_status LIKE ''' + @MaritalStatus + '''
						AND contact_info.city LIKE ''' + @City + '''
						AND contact_info.state LIKE ''' + @State + '''
						AND contact_info.country LIKE ''' + @Country + '''
						AND personal_info.profession LIKE ''' + @Profession + '''
						AND personal_info.education LIKE ''' + @Education + '''

						AND personal_info.religion LIKE ''' + @Religion + '''
						AND CONVERT (INT, personal_info.age) >= ''' + @MinAgeDesired + '''
						AND CONVERT (INT, personal_info.age) <= ''' + @MaxAgeDesired + '''
				
						AND CONVERT (INT, personal_info.height) >= ''' + @MinHeight + '''
						AND CONVERT (INT, personal_info.height) <= ''' + @MaxHeight + '''
						AND CONVERT (INT, personal_info.weight) >= ''' + @MinWeight + '''
						AND CONVERT (INT, personal_info.weight) <= ''' + @MaxWeight + '''
						AND personal_info.eyes LIKE ''' + @Eyes + '''
						AND personal_info.hair LIKE ''' + @Hair + '''
						AND personal_info.cook LIKE ''' + @Cook + '''
						AND personal_info.smoke LIKE ''' + @Smoke + '''
						AND personal_info.drink LIKE ''' + @Drink + '''
						AND personal_info.party LIKE ''' + @Party + '''
						AND personal_info.political LIKE ''' + @Political + '''
						AND personal_info.housing_status LIKE ''' + @HousingStatus + '''
						AND login_info.user_name = contact_info.user_name
						AND login_info.user_name = personal_info.user_name
						AND login_info.user_name = about_info.user_name
				)
			)
	ORDER BY ' + @OrderBy
	) -- end EXEC
SET ROWCOUNT 0
		RETURN 1
END -- Limit search by relationship type @Relationship != 0

END -- END find user_name

ELSE --------------------------- ALL OTHER SEARCHES ---------------------------------------------


BEGIN --------------------------- ALL OTHER SEARCHES ---------------------------------------------
-- Start DO NOT limit search by relationship type
IF (@Relationship = 0)
BEGIN
	PRINT 'Any Relationship count'
	-- Select the raw information by joining just the personal_info and relationship tables... 
SELECT CASE 
		WHEN COUNT(*) >= @GlobalRowCount THEN @GlobalRowCount
		ELSE COUNT(*)
	END 'Number of Rows 3'
		FROM login_info 
			, contact_info
			, personal_info
			, about_info
		WHERE login_info.sex LIKE @Seeking
		AND about_info.questionable = 0
		AND login_info.photo_submitted >= @Search
		AND CONVERT (INT, personal_info.sex_preference) >= @AlternativeMin
		AND CONVERT (INT, personal_info.sex_preference) <= @AlternativeMax

		AND personal_info.marital_status LIKE @MaritalStatus
		AND contact_info.city LIKE @City
		AND contact_info.state LIKE @State
		AND contact_info.country LIKE @Country
		AND personal_info.profession LIKE @Profession
		AND personal_info.education LIKE @Education
		AND personal_info.religion LIKE @Religion

		AND CONVERT (INT, personal_info.age) >= @MinAgeDesired
		AND CONVERT (INT, personal_info.age) <= @MaxAgeDesired

		AND CONVERT (INT, personal_info.height) >= @MinHeight
		AND CONVERT (INT, personal_info.height) <= @MaxHeight
		AND CONVERT (INT, personal_info.weight) >= @MinWeight
		AND CONVERT (INT, personal_info.weight) <= @MaxWeight

		AND 
		(
		about_info.screen_quote LIKE @TextSearch
		OR about_info.about_yourself LIKE @TextSearch
		)

		AND personal_info.eyes LIKE @Eyes
		AND personal_info.hair LIKE @Hair
		AND personal_info.cook LIKE @Cook
		AND personal_info.smoke LIKE @Smoke
		AND personal_info.drink LIKE @Drink
		AND personal_info.party LIKE @Party
		AND personal_info.political LIKE @Political		
		AND personal_info.housing_status LIKE @HousingStatus

		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = personal_info.user_name
		AND login_info.user_name = about_info.user_name

		PRINT 'Any Relationship Sort by ' + @OrderBy
		PRINT @Search


SET ROWCOUNT @RowCount
		
		-- Select the raw information by joining just the personal_info AND relationship tables... 
		EXEC ('SELECT login_info.user_name AS "user_name"
			, contact_info.city AS "city"
			, state.choice AS "state"
			, country.choice AS "country"
			, personal_info.age AS "age"
			, about_info.screen_quote AS "screen_quote"
			, about_info.about_yourself AS "about_yourself"
			, pictures.photo_1 AS "pic 1"

		FROM login_info
			, contact_info
			, personal_info
			, about_info
			, state
			, country
			, pictures
		WHERE login_info.user_name = contact_info.user_name
			AND login_info.photo_submitted >= ''' + @Search + '''
			AND login_info.user_name = personal_info.user_name
			AND login_info.user_name = about_info.user_name
			AND login_info.user_name = pictures.user_name
			AND contact_info.state = state.value
			AND contact_info.country = country.value
			AND personal_info.user_name IN 
			(
			SELECT login_info.user_name
				FROM login_info
					, contact_info
					, personal_info
					, about_info
				WHERE login_info.sex LIKE ''' + @Seeking + '''
				AND about_info.questionable = 0
				AND CONVERT (INT, personal_info.sex_preference) >= ''' + @AlternativeMin + '''
				AND CONVERT (INT, personal_info.sex_preference) <= ''' + @AlternativeMax + '''
	
				AND personal_info.marital_status LIKE ''' + @MaritalStatus + '''
				AND contact_info.city LIKE ''' + @City + '''
				AND contact_info.state LIKE ''' + @State + '''
				AND contact_info.country LIKE ''' + @Country + '''
				AND personal_info.profession LIKE ''' + @Profession + '''
				AND personal_info.education LIKE ''' + @Education + '''
				AND personal_info.religion LIKE ''' + @Religion + '''
		
				AND CONVERT (INT, personal_info.age) >= ''' + @MinAgeDesired + '''
				AND CONVERT (INT, personal_info.age) <= ''' + @MaxAgeDesired + '''
		
				AND CONVERT (INT, personal_info.height) >= ''' + @MinHeight + '''
				AND CONVERT (INT, personal_info.height) <= ''' + @MaxHeight + '''
				AND CONVERT (INT, personal_info.weight) >= ''' + @MinWeight + '''
				AND CONVERT (INT, personal_info.weight) <= ''' + @MaxWeight + '''
	
				AND 
				(
				about_info.screen_quote LIKE ''' + @TextSearch + '''
				OR about_info.about_yourself LIKE ''' + @TextSearch + '''
				)

				AND personal_info.eyes LIKE ''' + @Eyes + '''
				AND personal_info.hair LIKE ''' + @Hair + '''
				AND personal_info.cook LIKE ''' + @Cook + '''
				AND personal_info.smoke LIKE ''' + @Smoke + '''
				AND personal_info.drink LIKE ''' + @Drink + '''
				AND personal_info.party LIKE ''' + @Party + '''
				AND personal_info.political LIKE ''' + @Political + '''
				AND personal_info.housing_status LIKE ''' + @HousingStatus + '''
		
				AND login_info.user_name = contact_info.user_name
				AND login_info.user_name = personal_info.user_name
				AND login_info.user_name = about_info.user_name
			)
	
	ORDER BY ' + @OrderBy
	) -- end EXEC
SET ROWCOUNT 0
		RETURN 1
END -- Relationship = 0 "Any"





-- Start Limit search by relationship type
IF (@Relationship != 0)
BEGIN
PRINT 'Limit Relationship Count'
-- Select the raw information by joining just the personal_info and relationship tables... 
SELECT CASE 
		WHEN COUNT(*) >= @GlobalRowCount THEN @GlobalRowCount
		ELSE COUNT(*)
	END 'Number of Rows 4'
	FROM relationship 
	WHERE (
			relationship.prefer_not_to_say = @prefer_not_to_say	
			OR relationship.hang_out = @hang_out
			OR relationship.short_term = @short_term		
			OR relationship.long_term = @long_term				
			OR relationship.talk_email = @talk_email		
			OR relationship.photo_exchange = @photo_exchange		
			OR relationship.marriage = @marriage				
			OR relationship.other = @other
		  )
						
		AND relationship.user_name IN 
		(
			SELECT login_info.user_name
				FROM login_info
					, contact_info
					, personal_info
					, about_info
				WHERE login_info.user_name = contact_info.user_name
				AND about_info.questionable = 0
				AND login_info.user_name = personal_info.user_name
				AND login_info.user_name = about_info.user_name

				AND login_info.sex LIKE @Seeking
				AND login_info.photo_submitted >= @Search
				AND CONVERT (INT, personal_info.sex_preference) >= @AlternativeMin
				AND CONVERT (INT, personal_info.sex_preference) <= @AlternativeMax
				AND contact_info.city LIKE @City
				AND contact_info.state LIKE @State
				AND contact_info.country LIKE @Country
				AND personal_info.marital_status LIKE @MaritalStatus
				AND personal_info.profession LIKE @Profession
				AND personal_info.education LIKE @Education
				AND personal_info.religion LIKE @Religion

				AND CONVERT (INT, personal_info.age) >= @MinAgeDesired
				AND CONVERT (INT, personal_info.age) <= @MaxAgeDesired

				AND CONVERT (INT, personal_info.height) >= @MinHeight
				AND CONVERT (INT, personal_info.height) <= @MaxHeight
				AND CONVERT (INT, personal_info.weight) >= @MinWeight
				AND CONVERT (INT, personal_info.weight) <= @MaxWeight

				AND personal_info.eyes LIKE @Eyes
				AND personal_info.hair LIKE @Hair
				AND personal_info.cook LIKE @Cook
				AND personal_info.smoke LIKE @Smoke
				AND personal_info.drink LIKE @Drink
				AND personal_info.party LIKE @Party
				AND personal_info.political LIKE @Political
				AND personal_info.housing_status LIKE @HousingStatus
				AND 
				(
					about_info.screen_quote LIKE @TextSearch
					OR about_info.about_yourself LIKE @TextSearch
				)

		)
		PRINT 'Limit Relationship Sort by ' + @OrderBy

SET ROWCOUNT @RowCount

		-- Select the raw information by joining just the personal_info and relationship tables... 
		EXEC ('SELECT login_info.user_name AS "user_name"
			, contact_info.city AS "city"
			, state.choice AS "state"
			, country.choice AS "country"
			, personal_info.age AS "age"
			, about_info.screen_quote AS "screen_quote"
			, about_info.about_yourself AS "about_yourself"
			, pictures.photo_1 AS "pic 1"

		FROM login_info
			, contact_info
			, personal_info
			, about_info
			, state
			, country
			, pictures
		WHERE login_info.user_name = contact_info.user_name
			AND login_info.photo_submitted >= ''' + @Search + '''
			AND login_info.user_name = personal_info.user_name
			AND login_info.user_name = about_info.user_name
			AND login_info.user_name = pictures.user_name
			AND contact_info.state = state.value
			AND contact_info.country = country.value
			AND personal_info.user_name IN 
			(
			SELECT relationship.user_name
				FROM relationship 
			WHERE (
				relationship.prefer_not_to_say = ''' + @prefer_not_to_say + '''
				OR relationship.hang_out = ''' + @hang_out + '''
				OR relationship.short_term = ''' + @short_term + '''
				OR relationship.long_term = ''' + @long_term + '''				
				OR relationship.talk_email = ''' + @talk_email + '''		
				OR relationship.photo_exchange = ''' + @photo_exchange + '''
				OR relationship.marriage = ''' + @marriage + '''
				OR relationship.other = ''' + @other + '''
				)

			AND relationship.user_name IN 
					(
					SELECT login_info.user_name
						FROM login_info
							, contact_info
							, personal_info
							, about_info
						WHERE login_info.sex LIKE ''' + @Seeking + '''
						AND about_info.questionable = 0
						AND CONVERT (INT, personal_info.sex_preference) >= ''' + @AlternativeMin + '''
						AND CONVERT (INT, personal_info.sex_preference) <= ''' + @AlternativeMax + '''
						AND contact_info.city LIKE ''' + @City + '''
						AND contact_info.state LIKE ''' + @State + '''
						AND contact_info.country LIKE ''' + @Country + '''
						AND personal_info.marital_status LIKE ''' + @MaritalStatus + '''
						AND personal_info.profession LIKE ''' + @Profession + '''
						AND personal_info.education LIKE ''' + @Education + '''

						AND personal_info.religion LIKE ''' + @Religion + '''
						AND CONVERT (INT, personal_info.age) >= ''' + @MinAgeDesired + '''
						AND CONVERT (INT, personal_info.age) <= ''' + @MaxAgeDesired + '''
				
						AND CONVERT (INT, personal_info.height) >= ''' + @MinHeight + '''
						AND CONVERT (INT, personal_info.height) <= ''' + @MaxHeight + '''
						AND CONVERT (INT, personal_info.weight) >= ''' + @MinWeight + '''
						AND CONVERT (INT, personal_info.weight) <= ''' + @MaxWeight + '''

						AND 
						(
						about_info.screen_quote LIKE ''' + @TextSearch + '''
						OR about_info.about_yourself LIKE ''' + @TextSearch + '''
						)

						AND personal_info.eyes LIKE ''' + @Eyes + '''
						AND personal_info.hair LIKE ''' + @Hair + '''
						AND personal_info.cook LIKE ''' + @Cook + '''
						AND personal_info.smoke LIKE ''' + @Smoke + '''
						AND personal_info.drink LIKE ''' + @Drink + '''
						AND personal_info.party LIKE ''' + @Party + '''
						AND personal_info.political LIKE ''' + @Political + '''
						AND personal_info.housing_status LIKE ''' + @HousingStatus + '''
						AND login_info.user_name = contact_info.user_name
						AND login_info.user_name = personal_info.user_name
						AND login_info.user_name = about_info.user_name
				)
			)
	ORDER BY ' + @OrderBy
	) -- end EXEC
SET ROWCOUNT 0
		RETURN 1

END -- Limit search by relationship type @Relationship != 0

END	--- ALL OTHER SEARCHES ---

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [automatedCreateLoginInfo]
	-- login_info
@ID			nvarchar(10)
, @UserName		varchar(32)
, @MembershipType	int
, @Password		varchar(16)
, @PasswordHint	varchar(64)
, @Email		varchar(64)
, @Sex			char
, @PhotoSubmitted	int
	-- contact_info
, @FirstName		varchar(32)
, @LastName		varchar(32)
, @StreetAddress	varchar(96)
, @City			varchar(32)
, @State		varchar(32)
, @Country		varchar(32)
, @Zip			nchar(5)
, @Telephone		varchar(16)
	-- personal_info
, @SexPreference	varchar(2)
, @Age			varchar(4)
, @MaritalStatus		varchar(2)
, @Profession		varchar(3)
, @Education		varchar(2)
, @Religion		varchar(2)
, @Height		varchar(4)
, @Weight		varchar(4)
, @Eyes		varchar(2)
, @Hair			varchar(2)
, @MinAgeDesired	varchar(4)
, @MaxAgeDesired	varchar(4)
, @Cook		varchar(2)
, @Smoke		varchar(2)
, @Drink		varchar(2)
, @Party		varchar(2)
, @Political		varchar(2)
, @HousingStatus	varchar(2)
	-- relationship
, @Relationship		varchar(32)
	-- about_info
, @ScreenQuote	varchar(1024)
, @AboutYourself	varchar(8000)
	-- pictures
, @PictureName		varchar(32)

 AS
-- UserId must be declared 
DECLARE @@UserId int

-- membership_type, creation_date, and last_login must be declared 
DECLARE @@membership_type char
DECLARE @@creation_date datetime
DECLARE @@last_login datetime

-- Get the maximum +1 user_id number fron the login_info table 
select @@UserId = max(user_id + 1) from login_info

--  If there are no user ids in the database this is the first and therefore #1 
if @@UserId is NULL
select @@UserId = 1

-- Set the default values 
select @@creation_date = getdate()
select @@last_login = getdate()
select @@membership_type = '0' -- 0 = voyer 

-- Determine if the user_name is unique in the login_info table
if exists (select user_name from login_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 666 
	print 'user_name is not unique in login_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 666
END
else
BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'user_name IS unique in login_info'
	insert into login_info (user_id
			, user_name
			, password
			, password_hint
			, email
			, sex
			, membership_type
			, creation_date
			, last_login
			, photo_submitted
			) 
	values (@@UserId
		, @UserName
		, @Password
		, @PasswordHint
		, @Email
		, @Sex
		, @MembershipType
		, @@creation_date
		, @@last_login
		, @PhotoSubmitted
		)
END
-- Determine if the user_name is unique in the contact_info table
if exists (select user_name from contact_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 665
	print 'user_name is not unique in contact_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 665
END
else
BEGIN
	-- If the user_name is unique add the user to the contact_info table and exit with a return value of 1 
	print 'user_name IS unique in contact_info'
	insert into contact_info (user_name
			, first_name
			, last_name
			, street_address
			, city
			, state
			, country
			, zip
			, telephone
			) 
	values (@UserName
		, @FirstName
		, @LastName
		, @StreetAddress
		, @City
		, @State
		, @Country
		, @Zip
		, @Telephone
		)
END

-- Determine if the user_name is unique in the relationship table
if exists (select user_name from relationship where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 664
	print 'user_name is not unique in relationship' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 664
END
else
BEGIN
	-- If the user_name is unique add the user to the relationship table and exit with a return value of 1 
	print 'user_name IS unique in relationship'
		insert into relationship (user_name
				, prefer_not_to_say
				, any_relationship
				, hang_out
				, short_term
				, long_term
				, talk_email
				, photo_exchange
				, marriage
				, other
				) 
		values (@UserName
			, "1"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			)
END

-- Determine if the user_name is unique in the personal_info table
if exists (select user_name from personal_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 663
	print 'user_name is not unique in personal_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 663
END
else
BEGIN
	-- If the user_name is unique add the user to the personal_info table and exit with a return value of 1 
	print 'user_name IS unique in personal_info'
		insert into personal_info(user_name
				, sex_preference
				, age
				, marital_status
				, profession
				, education
				, religion
				, height
				, weight
				, eyes
				, hair
				, min_age_desired
				, max_age_desired
				, cook
				, smoke
				, drink
				, party
				, political
				, housing_status
				) 
		values (@UserName
			, "1"
			, @Age			 
			, @MaritalStatus 
			, @Profession	 
			, @Education	 
			, @Religion		 
			, @Height		 
			, @Weight		 
			, @Eyes			 
			, @Hair			 
			, @MinAgeDesired 
			, @MaxAgeDesired 
			, @Cook			 
			, @Smoke		 
			, @Drink		 
			, @Party		 
			, @Political	 
			, @HousingStatus 
			)
END
-- Determine if the user_name is unique in the about_info table
if exists (select user_name from about_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 662 
	print 'user_name is not unique in about_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 662
END
else
BEGIN
	-- If the user_name is unique add the user to the about_info table and exit with a return value of 1 
	print 'user_name IS unique in about_info'
	insert into about_info (user_name
			, screen_quote
			, about_yourself
			, questionable
			) 
	values (@UserName
		, @ScreenQuote
		, @AboutYourself
		, "1"
		)
END

-- Determine if the user_name is unique in the about_info table
if exists (select user_name from pictures where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 662 
	print 'user_name is not unique in pictures' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 661
END
else
BEGIN
	-- If the user_name is unique add the user to the pictures table and exit with a return value of 1 
print 'user_name IS unique in pictures'
insert into pictures (user_name
		, photo_1
		, photo_2
		, photo_3
		, photo_4
		, photo_5
		) 
values (@UserName
	, @PictureName
	, 'Nothing'
	, 'Nothing'
	, 'Nothing'
	, 'Nothing'
	)
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [automatedFixLoginInfo]
@UserName varchar(32)
, @Sex char

 AS

BEGIN
	print 'automatic sex change operation'
	update login_info 
		set sex = @Sex
		where user_name = @UserName
	return 1
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [batchNightlyTransactionSend]

 AS

-- change the user's membership_type to "0" (basic) if the promotion has ended or 
-- they have canceled their paying membership...
UPDATE login_info
	SET membership_type = 0 -- 0 = Basic Membership
	WHERE membership_type 
				IN
					(
					-- find all expired promotional membership_type_id's...
						SELECT membership_type_id
							FROM membership_type
							WHERE DATEDIFF( DAY, GETDATE(), date_promotion_ended ) < 0
							AND membership_type_id != 0
					)
				OR	
					(
					-- find all user_names with canceled paying memberships...
					membership_type 
							IN
								(
								-- find all NON promotional membership_type_id's...
									SELECT membership_type_id
										FROM membership_type
										WHERE date_promotion_ended IS NULL
										AND membership_type_id != 0
								)
					AND	user_name 
							IN 
								(
								-- find all user_names with inactive memberships 
								 -- past the date of membership expiration...
									SELECT user_name
										FROM billing_info
										WHERE is_membership_active = 0
										and DATEDIFF( DAY, GETDATE(), date_membership_expires ) < 0
								)
					)


-- Get all user_names that need to be billed
-- and put them in a tempory table...
DECLARE @@Description		VARCHAR(64)
DECLARE @@Amount			VARCHAR(8)
DECLARE @@PaymentMethod	VARCHAR(8)
DECLARE @@TransactionType	VARCHAR(18)
DECLARE @@IdentitySeed		VARCHAR(9)
SELECT @@Description	= 'Nightly credit card batch processing'
SELECT @@Amount 		= '9.99'
SELECT @@PaymentMethod	= 'CC'
SELECT @@TransactionType= 'AUTH_CAPTURE'
SELECT @@IdentitySeed 	=
		-- @@IdentitySeed += MM
			   CONVERT( VARCHAR, DATEPART(MINUTE, GETDATE()) )
		-- @@IdentitySeed += SS
			+ CONVERT( VARCHAR, DATEPART(SECOND, GETDATE()) )
		-- @@IdentitySeed += 0
			+ '0'

PRINT 'IdentitySeed		= '	+ @@IdentitySeed
PRINT 'Description		= '	+ @@Description
PRINT 'Amount			= '	+ @@Amount
PRINT 'PaymentMethod	= '	+ @@PaymentMethod
PRINT 'TransactionType	= '	+ @@TransactionType

EXEC('
	CREATE TABLE #Users_To_Be_Billed ( 
						invoice_number		INT 		NOT NULL IDENTITY(' + @@IdentitySeed + ', 1)
						, user_name 		VARCHAR(32)	NOT NULL
						, transaction_id 		VARCHAR(52)	NOT NULL
						, description	 	VARCHAR(64)	NOT NULL
						, amount	 	VARCHAR(8)	NOT NULL
						, payment_method 	VARCHAR(8)	NOT NULL
						, transaction_type 	VARCHAR(18)	NOT NULL
						, account_number 	VARCHAR(32)	NOT NULL
						, expiration_date 	VARCHAR(8)	NOT NULL
						)
	INSERT #Users_To_Be_Billed
		SELECT billing_info.user_name
			, billing_info.user_name
				-- @@TransactionId += _month
					+ ''_'' + CONVERT( VARCHAR,DATEPART(MONTH, GETDATE()) )
				-- @@TransactionId += _day
					+ ''_'' + CONVERT( VARCHAR,DATEPART(DAY, GETDATE()) )
				-- @@TransactionId += _year
					+ ''_'' + CONVERT( VARCHAR,DATEPART(YEAR, GETDATE()) )
				-- @@TransactionId += _hour
					+ ''_'' + CONVERT( VARCHAR,DATEPART(HOUR, GETDATE()) )
				-- @@TransactionId += _minute
					+ ''_'' + CONVERT( VARCHAR,DATEPART(MINUTE, GETDATE()) )
				-- @@TransactionId += _second
					+ ''_'' + CONVERT( VARCHAR,DATEPART(SECOND, GETDATE()) )
				AS ''transaction_id''
			, ''' + @@Description + ''' AS ''description''
			, ''' + @@Amount + ''' AS ''amount''
			, ''' + @@PaymentMethod + ''' AS ''payment_method''
			, ''' + @@TransactionType + ''' AS ''transaction_type''
			, billing_info.account_number
			, billing_info.expiration_month + ''/'' + RIGHT(billing_info.expiration_year, 2) AS ''expiration_date''
			FROM login_info
				, billing_info
			WHERE login_info.membership_type 
								IN
									(  -- find all NON promotional membership_type_ids...
										SELECT membership_type_id
											FROM membership_type
											WHERE date_promotion_ended IS NULL
											AND membership_type_id != 0
									)
			AND billing_info.is_membership_active = 1
			AND datediff( day, getdate(), billing_info.date_membership_expires ) < 0
			--AND login_info.user_name = billing_info.user_name

	SELECT * FROM #Users_To_Be_Billed
	DROP TABLE #Users_To_Be_Billed
	')
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [cancel_paying_membership]
 @UserName 		VARCHAR(    32)
, @Password		 VARCHAR(   16)
, @ReasonForLeaving	VARCHAR(    96)
, @MembershipPrices	VARCHAR(    32)
, @WebsiteDesign 	VARCHAR(  256)
, @Suggestions 	VARCHAR(3000)

 AS

IF ( (SELECT password FROM login_info WHERE user_name = @UserName) = @Password)
BEGIN

	DECLARE @@DateStartedPaying 	DATETIME
	DECLARE @@DateCancelled		DATETIME
	DECLARE @@Email 			VARCHAR(64)
	DECLARE @@IsMembershipActive	CHAR(1)
	DECLARE @@MembershipType 	CHAR(4)
	
	DECLARE @@UniqueId		INT
	-- Get the maximum +1 unique_id number fron the membership_cancellation table 
	select @@UniqueId = max(unique_id + 1) from membership_cancellation
	--  If there are no user ids in the database this is the first and therefore #1 
	if @@UniqueId is NULL
	select @@UniqueId = 1
	
	-- Set the current date 
	SELECT @@DateCancelled = GETDATE()
	
	-- Get user info from billing_info table...
	SELECT @@IsMembershipActive = (SELECT is_membership_active from billing_info where user_name = @UserName)
	
	-- Get user info from login_info table...
	SELECT @@DateStartedPaying = (SELECT date_started_paying from login_info where user_name = @UserName)
	SELECT @@Email = (SELECT email from login_info where user_name = @UserName)
	
	-- Check if user is already a paying member...
	SELECT @@MembershipType = (SELECT membership_type FROM login_info WHERE user_name = @UserName)
	
	IF(@@IsMembershipActive != '0' AND @@MembershipType != '0')
		BEGIN
		
				print 'insert a row into the membership_cancellation table'
				insert into membership_cancellation (unique_id
									, user_name
									, email
									, date_started_paying
									, date_cancelled
									, reason_for_leaving
									, membership_prices
									, website_design
									, suggestions
								         ) 
								values (@@UniqueId
									, @UserName
									, @@Email
									, @@DateStartedPaying
									, @@DateCancelled
									, @ReasonForLeaving
									, @MembershipPrices
									, @WebsiteDesign
									, @Suggestions
									)
				print 'update is_membership_active in the billing_info table'
				UPDATE billing_info
					SET is_membership_active = '0'
					WHERE user_name = @UserName
			RETURN 1
			
		END
	ELSE
		BEGIN
			PRINT 'ERROR:  User is not currently a paying member (' + @UserName + '):(' + @@IsMembershipActive + '):(' + @@MembershipType + ')'
			RETURN 206
		END
END
ELSE
	BEGIN-- Begin user_name and password DON'T match
		-- If the user_name does not exist, exit with a return value of 134
		print 'ERROR: User Name and Password did not match.'
		return 134
	END-- End user_name and password DON'T match
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [checkUsernamePassword]
	@UserName varchar(32)
	, @Password varchar (16)

 AS

if ( (select password from login_info where user_name = @UserName) = @Password)
BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Valid user_name and password combination'
return 0
END
else
BEGIN
	print 'user_name and password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [createLoginInfo]
@UserId int-- not used 
, @UserName varchar(32)
, @MembershipType char -- not used 
, @Password varchar(16)
, @PasswordHint varchar(64)
, @Email varchar(64)
, @Sex char
, @CreationDate varchar(32)-- not used 
, @LastLogin varchar(32) -- not used 
, @PhotoSubmitted int -- not used 

 AS
-- UserId must be declared 
DECLARE @@UserId int
DECLARE @@return_status int
-- membership_type, creation_date, and last_login must be declared 
DECLARE @@membership_type char
DECLARE @@creation_date datetime
DECLARE @@last_login datetime

-- Get the maximum +1 user_id number fron the login_info table 
select @@UserId = max(user_id + 1) from login_info

--  If there are no user ids in the database this is the first and therefore #1 
if @@UserId is NULL
select @@UserId = 1

-- Set the default values 
select @@creation_date = getdate()
select @@last_login = getdate()

select @@membership_type = '0' -- 0 = basic
--select @@membership_type = '1' -- 0 = premium

-- Determine if the user_name is unique in the login_info table
if exists (select user_name from login_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 666 
	print 'user_name is not unique in login_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 666
END
else
BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'user_name IS unique in login_info'
	insert into login_info (user_id
			, user_name
			, password
			, password_hint
			, email
			, sex
			, membership_type
			, creation_date
			, last_login
			, photo_submitted
			) 
	values (@@UserId
		, @UserName
		, @Password
		, @PasswordHint
		, @Email
		, @Sex
		, @@membership_type
		, @@creation_date
		, @@last_login
		, 0
		)
END
-- Determine if the user_name is unique in the contact_info table
if exists (select user_name from contact_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 665
	print 'user_name is not unique in contact_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 665
END
else
BEGIN
	-- If the user_name is unique add the user to the contact_info table and exit with a return value of 1 
	print 'user_name IS unique in contact_info'
	insert into contact_info (user_name
			, first_name
			, last_name
			, street_address
			, city
			, state
			, country
			, zip
			, telephone
			) 
	values (@UserName
		, ""
		, ""
		, ""
		, ""
		, "0"
		, "0"
		, ""
		, ""
		)
END

-- Determine if the user_name is unique in the relationship table
if exists (select user_name from relationship where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 664
	print 'user_name is not unique in relationship' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 664
END
else
BEGIN
	-- If the user_name is unique add the user to the relationship table and exit with a return value of 1 
	print 'user_name IS unique in relationship'
		insert into relationship (user_name
				, prefer_not_to_say
				, any_relationship
				, hang_out
				, short_term
				, long_term
				, talk_email
				, photo_exchange
				, marriage
				, other
				) 
		values (@UserName
			, "1"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			)
END

-- Determine if the user_name is unique in the personal_info table
if exists (select user_name from personal_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 663
	print 'user_name is not unique in personal_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 663
END
else
BEGIN
	-- If the user_name is unique add the user to the personal_info table and exit with a return value of 1 
	print 'user_name IS unique in personal_info'
		insert into personal_info(user_name
				, sex_preference
				, age
				, marital_status
				, profession
				, education
				, religion
				, height
				, weight
				, eyes
				, hair
				, min_age_desired
				, max_age_desired
				, cook
				, smoke
				, drink
				, party
				, political
				, housing_status
				) 
		values (@UserName
			, "1"
			, "18"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "18"
			, "99"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			, "0"
			)
END
-- Determine if the user_name is unique in the about_info table
if exists (select user_name from about_info where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 662 
	print 'user_name is not unique in about_info' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 662
END
else
BEGIN
	-- If the user_name is unique add the user to the about_info table and exit with a return value of 1 
	print 'user_name IS unique in about_info'
	insert into about_info (user_name
			, screen_quote
			, about_yourself
			, questionable
			) 
	values (@UserName
		, ""
		, ""
		, "1"
		)
END

-- Determine if the user_name is unique in the about_info table
if exists (select user_name from pictures where user_name = @UserName)
BEGIN
	-- If the user_name is not unique exit with a return value of 662 
	print 'user_name is not unique in pictures' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
	return 661
END
else
BEGIN
	-- If the user_name is unique add the user to the pictures table and exit with a return value of 1 
print 'user_name IS unique in pictures'
insert into pictures (user_name
		, photo_1
		, photo_2
		, photo_3
		, photo_4
		, photo_5
		) 
values (@UserName
	, 'Nothing'
	, 'Nothing'
	, 'Nothing'
	, 'Nothing'
	, 'Nothing'
	)
END

exec @@return_status = mailSendNewUserWelcome @UserName

if(@@return_status = 666)
	BEGIN
		print 'Mail could not be sent'
		return 666
	END
else
	BEGIN
		print 'Mail has been sent'
	END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [deleteMail]
	@UserName varchar(32)
	, @Password varchar (16)
	, @MailId varchar (16)


 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	if ( (select sent_from from mail where mail_id = @MailId) = @UserName)
	BEGIN
		print 'Update sender_deleted in mail table'
		update mail
		set sender_deleted = 1
		where mail_id = @MailId
		and @UserName = sent_from
	END

	if ( (select sent_to from mail where mail_id = @MailId) = @UserName)
	BEGIN
		print 'Update receiver_deleted in mail table'
		update mail
		set receiver_deleted = 1
		where mail_id = @MailId
		and @UserName = sent_to

		print 'Update when_read in mail table'
		update mail
		set receiver_deleted = 1
		, when_read = getdate()
		where mail_id = @MailId
		and @UserName = sent_to
		and when_read = NULL
	return 0
	END
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [deleteUserFromAllTables]
@UserName		varchar(32)
, @Password		varchar(16)

 AS

-- Determine if the user_name and password match
if ( (select password from login_info where user_name = @UserName) = @Password)
	BEGIN
		-- Determine if the user_name exists in the login_info table
		if exists (select user_name from login_info where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the login_info table 
				print 'Deleting user from login_info'
				delete login_info 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the user_name is not unique exit with a return value of 666 
				print 'user_name does not exist in the login_info table' -- 
			END
	
		-- Determine if the user_name exists in the contact_info table
		if exists (select user_name from contact_info where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the contact_info table 
				print 'Deleting user from contact_info'
				delete contact_info 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the user_name is not unique exit with a return value of 666 
				print 'user_name does not exist in the contact_info table' -- 
			END
	
		-- Determine if the user_name exists in the personal_info table
		if exists (select user_name from personal_info where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the personal_info table 
				print 'Deleting user from personal_info'
				delete personal_info 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the user_name is not unique exit with a return value of 666 
				print 'user_name does not exist in the personal_info table' -- 
			END
	
		-- Determine if the user_name exists in the relationship table
		if exists (select user_name from relationship where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the relationship table 
				print 'Deleting user from relationship'
				delete relationship 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the relationship is not unique exit with a return value of 666 
				print 'user_name does not exist in the relationship table' -- 
			END
	
		-- Determine if the user_name exists in the about_info table
		if exists (select user_name from about_info where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the about_info table 
				print 'Deleting user from about_info'
				delete about_info 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the user_name is not unique exit with a return value of 666 
				print 'user_name does not exist in the about_info table' -- 
			END
	
		-- Determine if the user_name exists in the pictures table
		if exists (select user_name from pictures where user_name = @UserName)
			BEGIN
				-- If the user_name exists delete the user from the pictures table 
				print 'Deleting user from pictures'
				delete pictures 
				where user_name = @UserName
			END
		else
			BEGIN
				-- If the user_name is not unique exit with a return value of 666 
				print 'user_name does not exist in the pictures table' -- 
			END
	END -- determine if the user_name and password match
else
	BEGIN
		-- If the user_name and password do not match exit
		print 'user_name and password did not match' -- the first part of this string must remain as "user_name is not unique" because it is being checked for in "msg_handler" 
		return 660
	END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genBookMarks]
	@UserName varchar(32)
	, @Password varchar (16)
 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	print 'Get total count'
	SELECT COUNT (*) AS  "count"
	FROM login_info
	WHERE user_name IN
		(
		SELECT book_mark
			FROM book_marks
			WHERE user_name = @UserName
		)
	print 'Get  table information'
	SELECT login_info.user_name as "user_name"
		, contact_info.city as "city"
		, state.choice as "state"
		, country.choice as "country"
		, personal_info.age as "age"
		, about_info.screen_quote as "screen_quote"
		, about_info.about_yourself as "about_yourself"
		, pictures.photo_1 as "pic 1"
	FROM login_info
		, contact_info
		, personal_info
		, about_info
		, state
		, country
		, pictures
	WHERE login_info.user_name = contact_info.user_name
		AND login_info.user_name = personal_info.user_name
		AND login_info.user_name = about_info.user_name
		AND login_info.user_name = pictures.user_name
		AND contact_info.state = state.value
		AND contact_info.country = country.value
		AND login_info.user_name in 
		(
		SELECT book_mark
			FROM book_marks
			WHERE user_name = @UserName
		)	return 0
END
else
BEGIN
	print 'ERROR: User Name and Password did not match genBookMarks.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genInbox]
	@UserName varchar(32)
	, @Password varchar (16)


 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserName, 'allow_mail_read'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN

	print 'Get message count sent to the user'	
	select count(login_info.user_name) as "count"
	from login_info
		, mail
		, pictures
	where login_info.user_name = @UserName
		and login_info.password = @Password
		and login_info.user_name = mail.sent_to
		and mail.receiver_deleted != 1
		and pictures.user_name = mail.sent_from


	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Get messages sent to the user'
	select login_info.user_name
		, login_info.membership_type
		, mail.mail_id
		, mail.sent_to
		, mail.sent_from
		, mail.subject
		, mail.message_text
		, mail.when_sent
		, mail.when_read
		, mail.sender_deleted
		, mail.receiver_deleted
		, pictures.photo_1
	from login_info
		, mail
		, pictures
	where login_info.user_name = @UserName
		and login_info.password = @Password
		and login_info.user_name = mail.sent_to
		and mail.receiver_deleted != 1
		and pictures.user_name = mail.sent_from
	order by mail.when_sent desc
return 0

END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genMemberHome]
	@UserName varchar(32)
	, @Password varchar (16)
	, @PromoDaysRemaining char(8) = ' '

 AS

DECLARE @@PremiumDaysRemaining	CHAR(8)
DECLARE @@MembershipType 		CHAR(4)
DECLARE @@IsMembershipActive		CHAR(1)
DECLARE @@DateMembershipExpires	DATETIME

-- Get membership_type from login_info table...
SELECT @@MembershipType = (SELECT membership_type FROM login_info WHERE user_name = @UserName)
-- Get is_membership_active from billing_info table...
SELECT @@IsMembershipActive = (SELECT is_membership_active from billing_info where user_name = @UserName)
-- Get date_membership_expires from billing_info table...
SELECT @@DateMembershipExpires = (SELECT date_membership_expires from billing_info where user_name = @UserName)

-- Only change the default value of @PromoDaysRemaining if the membership_type_id is promotional...
if (
	select datediff(day, getdate(), membership_type.date_promotion_ended) 
	from membership_type
		, login_info
	where login_info.user_name = @UserName
	and login_info.membership_type = membership_type.membership_type_id
  ) != NULL
	BEGIN
		print 'Get PromoDaysRemaining'
		select @PromoDaysRemaining = (
							select datediff(day, getdate(), membership_type.date_promotion_ended) 
							from membership_type
								, login_info
							where login_info.user_name = @UserName
							and login_info.membership_type = membership_type.membership_type_id
						    )
	END
ELSE
	BEGIN
		print 'Dont get PromoDaysRemaining'
	END

select @@PremiumDaysRemaining = ''
IF(@@IsMembershipActive = '0' AND( @@MembershipType = '1' OR  @@MembershipType = '2') )
	BEGIN
		print 'Get PremiumDaysRemaining'
		select @@PremiumDaysRemaining = (
							select datediff(day, getdate(), @@DateMembershipExpires) 
							from billing_info
							where billing_info.user_name = @UserName
						    )
	END
ELSE
	BEGIN
		print 'Dont get PremiumDaysRemaining'
	END


if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Get login_info table information'
	select login_info.user_name
		, login_info.membership_type
		, membership_type.membership_type_name
		, login_info.photo_submitted
		, about_info.questionable
		, @PromoDaysRemaining AS 'PromoDaysRemaining'
		, @@IsMembershipActive AS 'IsMembershipActive'
		, @@PremiumDaysRemaining AS 'PremiumDaysRemaining'
	from login_info
		, about_info
		, membership_type
	where login_info.user_name = @UserName
		and login_info.password = @Password
		and login_info.user_name = about_info.user_name
		and login_info.membership_type = membership_type.membership_type_id

	print 'Get messages sent to the user'
	select mail.mail_id
		, mail.sent_to
		, mail.sent_from
		, mail.subject
		, mail.message_text
		, mail.when_sent
		, mail.when_read
		, mail.sender_deleted
		, mail.receiver_deleted
	from mail
	where mail.sent_to = @UserName

	PRINT 'Update last_login'
	UPDATE login_info
	SET last_login =  GETDATE()
	WHERE user_name = @UserName

return 0

END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genOutbox]
	@UserName varchar(32)
	, @Password varchar (16)


 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserName, 'allow_mail_read'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN

	print 'Get message cound sent to the user'	
	select count(login_info.user_name) as "count"
	from login_info
		, mail
	where login_info.user_name = @UserName
		and login_info.password = @Password
		and mail.sender_deleted != 1
		and login_info.user_name = mail.sent_from


	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Get messages sent to the user'
	select login_info.user_name
		, login_info.membership_type
		, mail.mail_id
		, mail.sent_to
		, mail.sent_from
		, mail.subject
		, mail.message_text
		, mail.when_sent
		, mail.when_read
		, mail.sender_deleted
		, mail.receiver_deleted
		, pictures.photo_1
	from login_info
		, mail
		, pictures
	where login_info.user_name = @UserName
		and login_info.password = @Password
		and mail.sender_deleted != 1
		and login_info.user_name = mail.sent_from
		and pictures.user_name = mail.sent_to
	order by mail.when_sent desc
return 0

END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genPicUpload]
	@UserName varchar(32)
	, @Password varchar (16)


 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Get picture table information'
	select pictures.user_name
		, pictures.photo_1
		, pictures.photo_2
		, pictures.photo_3
		, pictures.photo_4
		, pictures.photo_5
	from pictures
	where pictures.user_name = @UserName

return 0

END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [genSendMail]
@UserNameBeingSearched varchar(32)
, @UserNameSearching varchar(32)

 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserNameSearching, 'allow_mail_send'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

/* Select the raw information by joining just the personal_info and relationship tables... */
print 'select all the info to generate the single profile information'
select login_info.user_id as "user_id"
	, login_info.user_name as "user_name"
	, login_info.membership_type as "membership_type"
	, sex.choice as "sex"
	, login_info.creation_date as "creation_date"
	, login_info.last_login as "last_login"
	, contact_info.city as "city"
	, state.choice as "state"
	, country.choice as "country"
	, sex_preference.choice as "sex_preference"
	, personal_info.age as "age"
	, marital_status.choice as "marital_status"
	, profession.choice as "profession"
	, education.choice as "education"
	, religion.choice as "religion"
	, height.choice as "height"
	, weight.choice  as "weight"
	, eyes.choice as "eyes"
	, hair.choice as "hair"
	, personal_info.min_age_desired
	, personal_info.max_age_desired
	, cook.choice as "cook"
	, smoke.choice as "smoke"
	, drink.choice as "drink"
	, party.choice as "party"
	, political.choice as "political"
	, housing_status.choice as "housing_status"
	, relationship.prefer_not_to_say as "prefer_not_to_say"
	, relationship.any_relationship as "any_relationship"
	, relationship.hang_out as "hang_out"
	, relationship.short_term as "short_term"
	, relationship.long_term as "long_term"
	, relationship.talk_email as "talk_email"
	, relationship.photo_exchange as "photo_exchange"
	, relationship.marriage as "marriage"
	, relationship.other as "other"
	, about_info.screen_quote as "screen_quote"
	, about_info.about_yourself as "about_yourself"
	, pictures.photo_1 as "pic 1"
	, pictures.photo_2 as "pic 2"
	, pictures.photo_3 as "pic 3"
	, pictures.photo_4 as "pic 4"
	, pictures.photo_5 as "pic 5"
from login_info
	, contact_info
	, personal_info
	, relationship
	, about_info
	, sex_preference
	, marital_status
	, profession
	, education
	, religion
	, height
	, weight
	, eyes
	, hair
	, cook
	, smoke
	, drink
	, party
	, political
	, housing_status
	, sex
	, state
	, country
	, pictures
where login_info.user_name = contact_info.user_name
	and login_info.user_name = personal_info.user_name
	and login_info.user_name = relationship.user_name
	and login_info.user_name = about_info.user_name
	and login_info.user_name = pictures.user_name
	and login_info.sex = sex.value
	and contact_info.state = state.value
	and contact_info.country = country.value
	and personal_info.sex_preference = sex_preference.value
	and personal_info.marital_status = marital_status.value
	and personal_info.profession = profession.value
	and personal_info.education = education.value
	and personal_info.religion = religion.value
	and personal_info.height = height.value
	and personal_info.weight = weight.value
	and personal_info.eyes = eyes.value
	and personal_info.hair = hair.value
	and personal_info.cook = cook.value
	and personal_info.smoke = smoke.value
	and personal_info.drink = drink.value
	and personal_info.party = party.value
	and personal_info.political = political.value
	and personal_info.housing_status = housing_status.value
	and personal_info.user_name = @UserNameBeingSearched

return 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [getAboutInfoByNamePassword]
	@UserName varchar(32)
	, @Password varchar (16)
 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
/* Get raw info */
	select user_name
		, screen_quote
		, about_yourself
		, questionable
	from about_info
	where user_name = @UserName

/* this is only needed to conform with the common database call that expects two result sets*/
	select user_name
		, screen_quote
		, about_yourself
		, questionable
	from about_info
	where user_name = @UserName

	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [getBillingInfoByNamePassword]
	@UserName VARCHAR(32)
	, @Password VARCHAR (16)
 AS

DECLARE @@CardType VARCHAR(16)
SELECT @@CardType = ''
SELECT @@CardType = 	(
				SELECT credit_card_type.choice
					FROM billing_info
						, credit_card_type 
				WHERE billing_info.user_name = @UserName
					and billing_info.card_type = credit_card_type.value 
				)	

IF ( (SELECT password FROM login_info WHERE user_name = @UserName) = @Password)
	BEGIN
		SELECT user_name
				, card_type
				, name_on_card
				, account_number
				, expiration_month
				, expiration_year
				, bank_ABA_code
				, bank_account_number
		FROM billing_info
		WHERE user_name = @UserName
		
		SELECT billing_info.user_name
				, @@CardType
				, billing_info.name_on_card
				, billing_info.account_number
				, billing_info.expiration_month
				, billing_info.expiration_year
				, billing_info.bank_ABA_code
				, billing_info.bank_account_number
		FROM billing_info
		WHERE billing_info.user_name = @UserName
		
		RETURN 1
	END
ELSE
	BEGIN
		PRINT 'ERROR: User Name and Password did not match.'
		RETURN 138
	END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [getContactInfoByNamePassword]
	@UserName varchar(32)
	, @Password varchar (16)
 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
select user_name
		, first_name
		, last_name
		, street_address
		, city
		, state
		, country
		, zip
		, telephone
from contact_info
where user_name = @UserName

select contact_info.user_name
		, contact_info.first_name
		, contact_info.last_name
		, contact_info.street_address
		, contact_info.city
		, state.choice as "state"
		, country.choice as "country"
		, contact_info.zip
		, contact_info.telephone
from contact_info, state, country
where user_name = @UserName
	and contact_info.state = state.value 
	and contact_info.country = country.value 

	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [getEmailByUserName]
	@UserName varchar(32)
 AS

BEGIN
/* Get raw login_info data */
	select email as 'email'
	from login_info
	where user_name = @UserName
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [getLoginInfoByEmailMaidenName]
	@Email varchar(32)
	, @MaidenName varchar (32)

 AS

if ( (select password_hint from login_info where email = @Email) = @MaidenName)
BEGIN
/* Get raw login_info data */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex
		, creation_date
		, last_login
		, photo_submitted

	from login_info

	where email = @Email
		and password_hint = @MaidenName

/* Get textual login_info data using a join */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex.choice as "sex"
		, creation_date
		, last_login
		, photo_submitted

	from login_info
		, sex

	where login_info.email = @Email
		and login_info.password_hint = @MaidenName
			and login_info.sex = sex.value
	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [getLoginInfoByNamePassword]
	@UserName varchar(32)
	, @Password varchar (16)
 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
/* Get raw login_info data */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex
		, creation_date
		, last_login
		, photo_submitted

	from login_info

	where user_name = @UserName
			and password = @Password

/* Get textual login_info data using a join */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex.choice as "sex"
		, creation_date
		, last_login
		, photo_submitted

	from login_info, sex

	where user_name = @UserName
			and password = @Password
			and login_info.sex = sex.value
	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [getLoginInfoByUserNameMaidenName]
	@UserName varchar(32)
	, @MaidenName varchar (16)

 AS

if ( (select password_hint from login_info where user_name = @UserName) = @MaidenName)
BEGIN
/* Get raw login_info data */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex
		, creation_date
		, last_login
		, photo_submitted

	from login_info

	where user_name = @UserName
		and password_hint = @MaidenName

/* Get textual login_info data using a join */
	select	user_id
		, user_name
		, membership_type
		, password
		, password_hint
		, email
		, sex.choice as "sex"
		, creation_date
		, last_login
		, photo_submitted

	from login_info
		, sex

	where login_info.user_name = @UserName
		and login_info.password_hint = @MaidenName
			and login_info.sex = sex.value
	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [getPersonalInfoByNamePassword]
	@UserName varchar(32)
	, @Password varchar (16)


 AS

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
print 'get raw info from personal_info and relationship tables'
/* Select the raw information by joining just the personal_info and relationship tables... */
	select personal_info.user_name		as "user_name"
 		, personal_info.sex_preference	as "sex_preference"
		, personal_info.age				as "age"
		, personal_info.marital_status	as "marital_status"
		, personal_info.profession		as "profession"
		, personal_info.education		as "education"
		, personal_info.religion		as "religion"
		, personal_info.height			as "height"
 		, personal_info.weight			as "weight"
		, personal_info.eyes			as "eyes"
		, personal_info.hair			as "hair"
		, personal_info.min_age_desired as "min_age_desired"
		, personal_info.max_age_desired as "max_age_desired"
		, personal_info.cook			as "cook"
		, personal_info.smoke			as "smoke"
		, personal_info.drink			as "drink"
		, personal_info.party			as "party"
		, personal_info.political		as "political"
		, personal_info.housing_status	as "housing_status"
		, relationship.prefer_not_to_say as "prefer_not_to_say"
		, relationship.any_relationship as "any_relationship"
		, relationship.hang_out			as "hang_out"
		, relationship.short_term		as "short_term"
		, relationship.long_term		as "long_term"
		, relationship.talk_email		as "talk_email"
		, relationship.photo_exchange	as "photo_exchange"
		, relationship.marriage			as "marriage"
		, relationship.other			as "other"

	from personal_info
		, relationship

	where personal_info.user_name = @UserName
	and personal_info.user_name = relationship.user_name

/* Select the textual information via a join... */
print 'get text info from personal_info and relationship tables'
	select personal_info.user_name 
 		, sex_preference.choice as "sex_preference"
		, personal_info.age as "age"
		, marital_status.choice as "marital_status"
		, profession.choice as "profession"
		, education.choice as "education"
		, religion.choice as "religion"
		, height.choice as "height"
 		, weight.choice  as "weight"
		, eyes.choice as "eyes"
		, hair.choice as "hair"
		, personal_info.min_age_desired
		, personal_info.max_age_desired
		, cook.choice as "cook"
		, smoke.choice as "smoke"
		, drink.choice as "drink"
		, party.choice as "party"
		, political.choice as "political"
		, housing_status.choice as "housing_status"
		, relationship.prefer_not_to_say as "prefer_not_to_say"
		, relationship.any_relationship as "any_relationship"
		, relationship.hang_out as "hang_out"
		, relationship.short_term as "short_term"
		, relationship.long_term as "long_term"
		, relationship.talk_email as "talk_email"
		, relationship.photo_exchange as "photo_exchange"
		, relationship.marriage as "marriage"
		, relationship.other as "other"

	from personal_info
		, sex_preference
		, marital_status
		, profession
		, education
		, religion
		, height
		, weight
		, eyes
		, hair
		, cook
		, smoke
		, drink
		, party
		, political
		, housing_status
		, relationship

	where personal_info.user_name = @UserName
	and personal_info.sex_preference = sex_preference.value
	and personal_info.marital_status = marital_status.value
	and personal_info.profession = profession.value
	and personal_info.education = education.value
	and personal_info.religion = religion.value
	and personal_info.height = height.value
	and personal_info.weight = weight.value
	and personal_info.eyes = eyes.value
	and personal_info.hair = hair.value
	and personal_info.cook = cook.value
	and personal_info.smoke = smoke.value
	and personal_info.drink = drink.value
	and personal_info.party = party.value
	and personal_info.political = political.value
	and personal_info.housing_status = housing_status.value
	and personal_info.user_name = relationship.user_name

	return 1
END

else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [hideUnhideProfile]
	@UserName varchar(32)
	, @Password varchar (16)

 AS

if ( (select password from login_info where user_name = @UserName) = @Password)
BEGIN
	if ( (select questionable from about_info where user_name = @UserName) = 0)
	BEGIN
		print 'Hide user profile'
		update about_info
		set questionable = 1
		where user_name = @UserName
	END
	else
	if ( (select questionable from about_info where user_name = @UserName) = 1)
	BEGIN
		print 'Unhide user profile'
		update about_info
		set questionable = 0
		where user_name = @UserName
	END
END
else
BEGIN
	print 'ERROR: User Name and Password did not match.'
	return 137
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [insert_membership_cancellation]
@UserName VARCHAR(32)
, @ReasonForLeaving VARCHAR(128)
, @MembershipPrices VARCHAR(16)
, @WebsiteDesign VARCHAR(16)
, @Suggestions TEXT

 AS

DECLARE @@Email VARCHAR(64)
DECLARE @@DateStartedPaying DATETIME
DECLARE @@DateCancelled DATETIME

-- Set the current date 
SELECT @@Email = (SELECT email FROM login_info WHERE user_name = @UserName)
SELECT @@DateStartedPaying = (SELECT date_started_paying FROM login_info WHERE user_name = @UserName)
SELECT @@DateCancelled = GETDATE()

-- Add @MonthsJoined to the DateOfThisTransaction to initialize the DateOfNextTransaction

-- If the user_name is unique add the user to the billing_info table
print 'insert cancellation information into membership_cancellation table'
insert into membership_cancellation (user_name
					, email
					, date_started_paying
					, date_cancelled
					, reason_for_leaving
					, membership_prices
					, website_design
					, suggestions
					) 
				values (@UserName
					, @@Email
					, @@DateStartedPaying
					, @@DateCancelled
					, @ReasonForLeaving
					, @MembershipPrices
					, @WebsiteDesign
					, @Suggestions
					)

-- update billing_info table to reflect the cancellation
print 'update is_membership_active to NO "0" in billing_info table'
UPDATE billing_info 
SET is_membership_active = '0'
WHERE user_name = @UserName

RETURN 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [mailSend]
@MailId int -- not used
, @SentTo varchar(32)
, @SentFrom varchar(32)
, @Subject varchar(128)
, @MessageText varchar(3000)
, @WhenSent datetime
, @WhenRead datetime
, @SenderDeleted int --not used
, @ReceiverDeleted int --not used

 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @SentTo, 'allow_mail_send'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

-- UserId must be declared 
DECLARE @@MailId int
-- Get the maximum +1 mail_id number fron the mail table 
select @@MailId = max(mail_id + 1) from mail

--  If there are no mail ids in the database this is the first and therefore #1 
if @@MailId is NULL
select @@MailId = 1

DECLARE @@MembershipType int
-- Set the default values 
select @WhenSent = getdate()
select @@MembershipType = (select membership_type from login_info where user_name = @SentFrom)

-- Determine if the user_name has mailing permission in the login_info table
if (@@MembershipType = 0 OR @@MembershipType = NULL)
BEGIN
	-- If the user_name is not unique exit with a return value of 666 
	print 'membership_type does not permit mail' --message_handler needs this exact string
	return 666
END


if exists (select user_name from login_info where user_name = @SentTo)
BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Posting new mail message to mail table'
	insert into mail ( mail_id
			, sent_to
			, sent_from
			, subject
			, message_text
			, when_sent
			, sender_deleted
			, receiver_deleted
			) 
	values ( @@MailId
		, @SentTo
		, @SentFrom
		, @Subject
		, @MessageText
		, @WhenSent
		, 0	
		, 0	
		)
return 0
END
else
BEGIN
	-- If the user_name does not exist exit with a return value of 666 
	print 'user_name does not exist'
	return 665
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [mailSendNewUserWelcome]
@SentTo varchar(32)

 AS

DECLARE @@WhenSent datetime
-- UserId must be declared 
DECLARE @@MailId int
-- Get the maximum +1 mail_id number fron the mail table 
select @@MailId = max(mail_id + 1) from mail

--  If there are no mail ids in the database this is the first and therefore #1 
if @@MailId is NULL
select @@MailId = 1

-- Set the default values 
select @@WhenSent = getdate()

if exists (select user_name from login_info where user_name = @SentTo)
BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Posting new mail message to mail table'
	insert into mail (mail_id
			, sent_to
			, sent_from
			, subject
			, message_text
			, when_sent
			, sender_deleted
			, receiver_deleted
			) 
	values ( @@MailId
		, @SentTo
		, 'PersianConnections'
		, 'Welcome!'
		, 'Thank you for submitting your profile on PersianConnections.com'
		, @@WhenSent
		, 0	
		, 0	
		)
return 0
END
else
BEGIN
	-- If the user_name does not exist exit with a return value of 666 
	print 'user_name does not exist'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [massMail_FindDuplicates]
 @DupToFind VARCHAR(64) 		= 'email'
, @TableWithDup VARCHAR(64) 	= 'login_info'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT 'Order by ' + @TableWithDup + '.' + @DupToFind


-- count the total number of rows in the login_info table...
EXEC ( 'SELECT ' + @DupToFind + '
		INTO #dups FROM  ' + @TableWithDup + '
		GROUP BY ' + @DupToFind + '
		HAVING COUNT(*) > 1

SELECT COUNT(*) AS "count"
	FROM ' + @TableWithDup +'
		, #dups
	WHERE ' + @TableWithDup + '.' + @DupToFind + ' = #dups.' + @DupToFind + '


SELECT login_info.user_name		AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, sex.choice			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.first_name		AS "first_name"
		, contact_info.last_name		AS "last_name"
		, contact_info.street_address	AS "street_address"
		, contact_info.city		AS "city"
		, state.choice			AS "state"
		, country.choice			AS "country"
		, contact_info.zip		AS "zip"
		, contact_info.telephone		AS "telephone"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
		, sex
		, state
		, country
		, #dups
	WHERE ' + @TableWithDup + '.' + @DupToFind + ' = #dups.' + @DupToFind + '
		AND login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
		AND login_info.sex = sex.value
		AND contact_info.state = state.value
		AND contact_info.country = country.value
	ORDER BY  ' + @TableWithDup  + '.' + @DupToFind
) -- end EXEC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [massMail_GetAllUsers]

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

-- count the total number of rows in the login_info table...
SELECT COUNT(*) AS "count"
	FROM login_info

SELECT login_info.user_name		AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, sex.choice			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.first_name		AS "first_name"
		, contact_info.last_name		AS "last_name"
		, contact_info.street_address	AS "street_address"
		, contact_info.city		AS "city"
		, state.choice			AS "state"
		, country.choice			AS "country"
		, contact_info.zip		AS "zip"
		, contact_info.telephone		AS "telephone"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
		, sex
		, state
		, country
	WHERE  login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
		AND login_info.sex = sex.value
		AND contact_info.state = state.value
		AND contact_info.country = country.value
	ORDER BY  login_info.email
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [massMail_GetUsersWithUnreadMail]

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

SELECT COUNT(*) AS 'count'
	FROM login_info
	WHERE user_name IN (
				SELECT sent_to 
					FROM mail 
					WHERE when_read IS NULL
			   	 )

SELECT login_info.user_name			AS "user_name"
		, login_info.password		AS "password"
		, login_info.email		AS "email"
		, sex.choice			AS "sex"
		, pictures.photo_1		AS "photo_1"
		, pictures.photo_2		AS "photo_2"
		, pictures.photo_3		AS "photo_3"
		, pictures.photo_4		AS "photo_4"
		, pictures.photo_5		AS "photo_5"
		, contact_info.first_name		AS "first_name"
		, contact_info.last_name		AS "last_name"
		, contact_info.street_address	AS "street_address"
		, contact_info.city		AS "city"
		, state.choice			AS "state"
		, country.choice			AS "country"
		, contact_info.zip		AS "zip"
		, contact_info.telephone		AS "telephone"
		, about_info.screen_quote	AS "screen_quote"
		, about_info.about_yourself	AS "about_yourself"
		, about_info.questionable	AS "questionable"
		, login_info.creation_date	AS "creation_date"
		, login_info.last_login		AS "last_login"
	FROM login_info
		, pictures
		, contact_info
		, about_info
		, sex
		, state
		, country
	WHERE  login_info.user_name IN (
						SELECT sent_to 
							FROM mail 
							WHERE when_read IS NULL
					)
		AND login_info.user_name = pictures.user_name
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = about_info.user_name
		AND login_info.sex = sex.value
		AND contact_info.state = state.value
		AND contact_info.country = country.value
	ORDER BY  login_info.email
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [readReceivedMail]
	@UserName varchar(32)
	, @Password varchar (16)
	, @MailId varchar (16)
 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserName, 'allow_mail_read'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

if ( (select password from login_info where user_name = @UserName) = @Password)
	BEGIN-- Begin user_name and password match
		-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
		print 'Retrieving actual mail message from mail table'
		select mail.mail_id
			, mail.sent_to
			, mail.sent_from
			, mail.subject
			, mail.message_text
			, mail.when_sent
			, mail.when_read
			, mail.sender_deleted
			, mail.receiver_deleted
			, contact_info.city
			, contact_info.state
			, personal_info.age
			, pictures.photo_1
		from mail
		, contact_info
		, personal_info
		, state
		, pictures
		where @MailId like mail.mail_id
		and state.value = contact_info.state
		and contact_info.user_name = mail.sent_from
		and personal_info.user_name = mail.sent_from
		and mail.sent_to = @UserName
		and pictures.user_name = mail.sent_from

		print 'Retrieving data mail message from mail table'
		select mail.mail_id
			, mail.sent_to
			, mail.sent_from
			, mail.subject
			, mail.message_text
			, mail.when_sent
			, mail.when_read
			, mail.sender_deleted
			, mail.receiver_deleted
			, contact_info.city
			, state.choice as "state"
			, personal_info.age
			, pictures.photo_1
		from mail
		, contact_info
		, personal_info
		, state
		, pictures
		where @MailId like mail.mail_id
		and state.value = contact_info.state
		and contact_info.user_name = mail.sent_from
		and personal_info.user_name = mail.sent_from
		and mail.sent_to = @UserName
		and pictures.user_name = mail.sent_from

		print 'Updating when_read mail field'
		update mail
		set when_read= getdate()
		where @MailId like mail.mail_id

	return 0
	END-- End user_name and password match
ELSE
	BEGIN-- Begin user_name and password DON'T match
		-- If the user_name does not exist exit with a return value of 666 
		print 'ERROR: User Name and Password did not match.'
		return 134
	END-- End user_name and password DON'T match
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [readSentMail]
	@UserName varchar(32)
	, @Password varchar (16)
	, @MailId varchar (16)


 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserName, 'allow_mail_read'
-- Check membership_type for permission
if ( @@ReturnValue != 1	)
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

if ( (select password from login_info where user_name = @UserName) = @Password)

BEGIN
	-- If the user_name is unique add the user to the login_info table and exit with a return value of 1 
	print 'Retrieving actual mail message from mail table'
	select mail.mail_id
		, mail.sent_to
		, mail.sent_from
		, mail.subject
		, mail.message_text
		, mail.when_sent
		, mail.when_read
		, mail.sender_deleted
		, mail.receiver_deleted
		, contact_info.city
		, contact_info.state
		, personal_info.age
		, pictures.photo_1
	from mail
	, contact_info
	, personal_info
	, state
	, pictures
	where @MailId = mail.mail_id
	and state.value = contact_info.state
	and contact_info.user_name = mail.sent_from
	and personal_info.user_name = mail.sent_from
	and mail.sent_from = @UserName
	and pictures.user_name = mail.sent_from

	print 'Retrieving data mail message from mail table'
	select mail.mail_id
		, mail.sent_to
		, mail.sent_from
		, mail.subject
		, mail.message_text
		, mail.when_sent
		, mail.when_read
		, mail.sender_deleted
		, mail.receiver_deleted
		, contact_info.city
		, state.choice as "state"
		, personal_info.age
		, pictures.photo_1
	from mail
	, contact_info
	, personal_info
	, state
	, pictures
	where @MailId = mail.mail_id
	and state.value = contact_info.state
	and contact_info.user_name = mail.sent_from
	and personal_info.user_name = mail.sent_from
	and mail.sent_from = @UserName
	and pictures.user_name = mail.sent_from

return 0
END
else
BEGIN
	-- If the user_name does not exist exit with a return value of 666 
	print 'ERROR: User Name and Password did not match.'
	return 666
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [simpleSearch]
 @Search int
, @IAm char(1)
, @Seeking char(1)
, @City varchar(32)
, @State varchar(2)
, @Country varchar(3)
, @MinAgeDesired varchar(2)
, @MaxAgeDesired varchar(2)
, @Limit int
, @Sort varchar(16)
, @Index varchar(6)

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

declare @GlobalRowCount INT
SELECT @GlobalRowCount = 500;

DECLARE @AlternativeMin	INT		-- Used as lower bound for sex_preference searches
DECLARE @AlternativeMax 	INT		-- Used as upper bound for sex_preference searches

-- Determine what sexual preference search needs to be performed...
IF (@IAm = @Seeking AND @IAm > "0")
BEGIN
	-- Same sex search...
	PRINT 'same sex search'
	SELECT @AlternativeMin = 2
	SELECT @AlternativeMax = 4
END
ELSE
	BEGIN
		-- Opposite sex search...
		PRINT 'opposite sex search'
		SELECT @AlternativeMin = 0
		SELECT @AlternativeMax = 1
	END
-- Check for city variable...
IF (@City = "")
BEGIN
	-- If no city has been entered then default to the match any string wildcard...
	SELECT @City = '%'
	PRINT 'City = ' + @City
END

-- Check for city variable...
IF (@State = "0")
BEGIN
	-- If no state has been entered then default to the match any string wildcard...
	SELECT @State = '%'
	PRINT 'State = ' + @State
END

-- Check for country variable...
IF (@Country = "0")
BEGIN
	-- If no country has been entered then default to the match any string wildcard...
	SELECT @Country = '%'
	PRINT 'Country = ' + @Country
END

-- Determin how the user whats the results ordered...
DECLARE @OrderBy CHAR(32) 	-- Holds the order by clause condition
IF( @Sort = 'user_name' )
	BEGIN
		SELECT @OrderBy = 'contact_info.user_name'
	END
ELSE
	IF( @Sort = 'state' )
		BEGIN
			SELECT @OrderBy = 'contact_info.state'
		END
	ELSE
		IF( @Sort = 'age' )
		BEGIN
			SELECT @OrderBy = 'personal_info.age'
		END
		ELSE
			IF( @Sort = 'creation_date' )
			BEGIN
				SELECT @OrderBy = 'login_info.creation_date DESC'
			END

PRINT 'Order by ' + @OrderBy

-- the SET ROWCOUNT limits the number of rows affected
SET ROWCOUNT @GlobalRowCount

/* Select the raw information by joining just the personal_info and relationship tables... */
SELECT CASE 
		WHEN COUNT(*) >= @GlobalRowCount THEN @GlobalRowCount
		ELSE COUNT(*)
	END 'Number of Rows'
	FROM login_info
		, contact_info
		, personal_info
		, about_info
	WHERE login_info.sex like @Seeking
	AND login_info.photo_submitted >= @Search
	AND personal_info.sex_preference >= @AlternativeMin
	AND personal_info.sex_preference <= @AlternativeMax
	AND contact_info.city like @City
	AND contact_info.state like @State
	AND contact_info.country like @Country
	AND personal_info.age >= @MinAgeDesired
	AND personal_info.age <= @MaxAgeDesired
	AND about_info.questionable = 0
	AND login_info.user_name = contact_info.user_name
	AND login_info.user_name = personal_info.user_name
	AND login_info.user_name = about_info.user_name

DECLARE @RowCount	INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 2 )

SET ROWCOUNT @RowCount

-- Select the all the information by joining the tables... 
EXEC ('SELECT login_info.user_name as "user_name"
	, contact_info.city as "city"
	, state.choice as "state"
	, country.choice as "country"
	, personal_info.age as "age"
	, about_info.screen_quote as "screen_quote"
	, about_info.about_yourself as "about_yourself"
	, pictures.photo_1 as "pic 1"

FROM login_info
	, contact_info
	, personal_info
	, about_info
	, state
	, country
	, pictures
WHERE login_info.user_name = contact_info.user_name
	AND login_info.user_name = personal_info.user_name
	AND login_info.user_name = about_info.user_name
	AND login_info.user_name = pictures.user_name
	AND contact_info.state = state.value
	AND contact_info.country = country.value
	AND login_info.user_name in 
	(
	SELECT login_info.user_name
		FROM login_info
			, contact_info
			, personal_info
			, about_info
		WHERE login_info.sex LIKE ''' + @Seeking +'''
		AND login_info.photo_submitted >= '''+ @Search + '''
		AND personal_info.sex_preference >= ''' + @AlternativeMin + '''
		AND personal_info.sex_preference <= ''' + @AlternativeMax + '''
		AND contact_info.city LIKE ''' + @City + '''
		AND contact_info.state LIKE ''' + @State + '''
		AND contact_info.country LIKE ''' + @Country + '''
		AND personal_info.age >= ''' + @MinAgeDesired + '''
		AND personal_info.age <= ''' + @MaxAgeDesired + '''
		AND about_info.questionable = 0
		AND login_info.user_name = contact_info.user_name
		AND login_info.user_name = personal_info.user_name
		AND login_info.user_name = about_info.user_name
	)

ORDER BY ' + @OrderBy
)

SET ROWCOUNT 0

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [singleProfile]
@UserNameBeingSearched varchar(32)
, @UserNameSearching varchar(32)

 AS

-- START Verify Permissions
DECLARE @@ReturnValue char(4)
DECLARE @@ViewMyOwnProfile char(2)

IF(@UserNameBeingSearched = @UserNameSearching )
	BEGIN
		SELECT @@ViewMyOwnProfile = '1'
	END
ELSE
	BEGIN
		SELECT @@ViewMyOwnProfile = '0'
	END

EXEC @@ReturnValue = verifyMembershipTypePermissions  @UserNameSearching, 'allow_view_profiles'
-- Check membership_type for permission
IF ( @@ReturnValue != 1 AND  @@ViewMyOwnProfile = '0' )
	BEGIN--  DENIED
		print 'You must upgrade your membership to use this feature'
		return @@ReturnValue
	END
-- END Verify Permissions

-- Check if the UserNameBeingSearched is hidden...
SELECT @@ReturnValue = (select questionable from about_info where user_name = @UserNameBeingSearched)
if ( @@ReturnValue = 1 AND @@ViewMyOwnProfile = '0' )
	BEGIN--  DENIED
		print 'The user you are trying to view currently has a hidden profile'
		return 205
	END

/* Select the raw information by joining just the personal_info and relationship tables... */
print 'select all the info to generate the single profile information'
select login_info.user_id as "user_id"
	, login_info.user_name as "user_name"
	, login_info.membership_type as "membership_type"
	, sex.choice as "sex"
	, login_info.creation_date as "creation_date"
	, login_info.last_login as "last_login"
	, contact_info.city as "city"
	, state.choice as "state"
	, country.choice as "country"
	, sex_preference.choice as "sex_preference"
	, personal_info.age as "age"
	, marital_status.choice as "marital_status"
	, profession.choice as "profession"
	, education.choice as "education"
	, religion.choice as "religion"
	, height.choice as "height"
	, weight.choice  as "weight"
	, eyes.choice as "eyes"
	, hair.choice as "hair"
	, personal_info.min_age_desired
	, personal_info.max_age_desired
	, cook.choice as "cook"
	, smoke.choice as "smoke"
	, drink.choice as "drink"
	, party.choice as "party"
	, political.choice as "political"
	, housing_status.choice as "housing_status"
	, relationship.prefer_not_to_say as "prefer_not_to_say"
	, relationship.any_relationship as "any_relationship"
	, relationship.hang_out as "hang_out"
	, relationship.short_term as "short_term"
	, relationship.long_term as "long_term"
	, relationship.talk_email as "talk_email"
	, relationship.photo_exchange as "photo_exchange"
	, relationship.marriage as "marriage"
	, relationship.other as "other"
	, about_info.screen_quote as "screen_quote"
	, about_info.about_yourself as "about_yourself"
	, pictures.photo_1 as "pic 1"
	, pictures.photo_2 as "pic 2"
	, pictures.photo_3 as "pic 3"
	, pictures.photo_4 as "pic 4"
	, pictures.photo_5 as "pic 5"
from login_info
	, contact_info
	, personal_info
	, relationship
	, about_info
	, sex_preference
	, marital_status
	, profession
	, education
	, religion
	, height
	, weight
	, eyes
	, hair
	, cook
	, smoke
	, drink
	, party
	, political
	, housing_status
	, sex
	, state
	, country
	, pictures
where login_info.user_name = contact_info.user_name
	and login_info.user_name = personal_info.user_name
	and login_info.user_name = relationship.user_name
	and login_info.user_name = about_info.user_name
	and login_info.user_name = pictures.user_name
	and login_info.sex = sex.value
	and ( 
		about_info.questionable = 0 
		OR 
		@@ViewMyOwnProfile = '1' 
	         )
	and contact_info.state = state.value
	and contact_info.country = country.value
	and personal_info.sex_preference = sex_preference.value
	and personal_info.marital_status = marital_status.value
	and personal_info.profession = profession.value
	and personal_info.education = education.value
	and personal_info.religion = religion.value
	and personal_info.height = height.value
	and personal_info.weight = weight.value
	and personal_info.eyes = eyes.value
	and personal_info.hair = hair.value
	and personal_info.cook = cook.value
	and personal_info.smoke = smoke.value
	and personal_info.drink = drink.value
	and personal_info.party = party.value
	and personal_info.political = political.value
	and personal_info.housing_status = housing_status.value
	and personal_info.user_name = @UserNameBeingSearched

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [transaction_credit_card_receive]
@TransactionID CHAR(52)
, @XResponseCode CHAR(1)
, @XResponseSubcode CHAR(6)
, @XResponseReasonCode CHAR(2)
, @XResponseReasonText VARCHAR(320)
, @XAuthCode CHAR(8)
, @XAvsCode CHAR(1)
, @XMd5Hash VARCHAR(50)

 AS

DECLARE @@UserName CHAR(32)
SELECT @@UserName = (SELECT user_name from transactions_log WHERE transaction_id = @TransactionID)

-- update the transactions_log table with the fields returned from Authorize.Net
UPDATE transactions_log 
	SET x_response_code  	= @XResponseCode
	        , x_response_subcode	= @XResponseSubcode
	        , x_response_reason_code 	= @XResponseReasonCode
	        , x_response_reason_text 	= @XResponseReasonText
	        , x_auth_code 		= @XAuthCode
	        , x_avs_code 		= @XAvsCode
	        , x_md5_hash 		= @XMd5Hash
	WHERE transaction_id = @TransactionID

-- If @XResponseCode = 1 update the membership type to 1
IF (@XResponseCode = "1")
	BEGIN
		IF( (SELECT date_started_paying FROM login_info where user_name = @@UserName) = NULL)
			BEGIN
				-- update login_info table to reflect the successful transaction
				UPDATE login_info 
					SET membership_type 	= '1'
						, date_started_paying =  (SELECT date_of_this_transaction from transactions_log WHERE transaction_id = @TransactionID)
					WHERE user_name = @@UserName
			END
		ELSE
			BEGIN
				-- update login_info table to reflect the successful transaction
				UPDATE login_info 
					SET membership_type 	= '1'
					WHERE user_name = @@UserName
			END

		-- update billing_info table to reflect the successful transaction
		UPDATE billing_info 
			SET is_membership_active = '1'
				, date_membership_expires =  (SELECT date_of_next_transaction from transactions_log WHERE transaction_id = @TransactionID)
			WHERE user_name = @@UserName
		
		PRINT 'login_info and billing_info were updated:   x_response_code = (' + @XResponseCode + ')'
	END
ELSE
	BEGIN
		PRINT 'login_info and billing_info were not updated because x_response_code = (' + @XResponseCode + ')'
	END

RETURN 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [transaction_credit_card_send]
@TransactionID CHAR(52)
, @BatchTransactionID VARCHAR(60)
, @UserName VARCHAR(32)
, @MonthsJoined CHAR(2)
, @Amount VARCHAR(8)
, @NameOnCard VARCHAR(64)
, @CardType CHAR(1)
, @AccountNumber VARCHAR(32)
, @ExpirationMonth CHAR(2)
, @ExpirationYear CHAR(4)
, @TransactionType VARCHAR(18)
, @XTransID CHAR(9)
, @XDescription VARCHAR(256)
, @XMethod VARCHAR(18)
, @BankABACode VARCHAR(9)
, @BankAccountNumber VARCHAR(32)

 AS

DECLARE @@DateOfThisTransaction DATETIME
DECLARE @@DateOfNextTransaction DATETIME

DECLARE @@MembershipType 	CHAR(4)
DECLARE @@IsMembershipActive	CHAR(1)

DECLARE @@UserId			VARCHAR(10)
SELECT @@UserId = (SELECT user_id from login_info where user_name = @UserName)

-- Get user info from billing_info table...
SELECT @@IsMembershipActive = (SELECT is_membership_active from billing_info where user_name = @UserName)
	
print 'Method = ' + @XMethod

-- Check if user is already a paying member...
SELECT @@MembershipType = (SELECT membership_type from login_info where user_name = @UserName)
IF( (@@MembershipType != '1' AND @@MembershipType != '2') OR @TransactionType = 'CREDIT' OR ( @@IsMembershipActive = '0' AND (@@MembershipType = '1' OR @@MembershipType = '2') ) )
	BEGIN
	
		-- Set the current date 
		SELECT @@DateOfThisTransaction = GETDATE()
		
		-- Add @MonthsJoined to the DateOfThisTransaction to initialize the DateOfNextTransaction
		SELECT @@DateOfNextTransaction = DATEADD(MONTH, CONVERT (INT, @MonthsJoined), @@DateOfThisTransaction)
		
			print 'Updating the Credit Card info in the billing_info table'
			-- Determine if the user_name is unique in the billing_info table
			if exists (select user_name from billing_info where user_name = @UserName)
			BEGIN
				-- Update the proper columns based on which method of transaction this is...
				IF (@XMethod = 'CC')
					BEGIN
						-- If the user_name is NOT unique update the billing_info table with the current information
						print 'update billing_info table'
						update billing_info 
							set card_type = @CardType
								, name_on_card = @NameOnCard
								, expiration_month = @ExpirationMonth
								, expiration_year = @ExpirationYear
								, bank_ABA_code = @BankABACode
								, bank_account_number = @BankAccountNumber
							where user_name = @UserName
					END
				ELSE
					BEGIN
						-- If the user_name is NOT unique update the billing_info table with the current information
						print 'update billing_info table'
						update billing_info 
							set bank_ABA_code = @BankABACode
								, bank_account_number = @BankAccountNumber
							where user_name = @UserName
					END
				
			-- Needs Refining...
				-- Add the new number of months_joined (* 30 in days) to the curent date_membership_expires...
				-- SELECT @@DateOfNextTransaction = DATEADD(DAY, CONVERT ( INT, (@MonthsJoined * 30) ), (SELECT date_membership_expires FROM billing_info) )
			END
			else
			BEGIN
				-- If the user_name is unique add the user to the billing_info table
				print 'user_name IS unique in billing_info'
				insert into billing_info (user_name
						, card_type
						, name_on_card
						, account_number
						, expiration_month
						, expiration_year
						, is_membership_active
						, date_membership_expires
						, bank_ABA_code
						, bank_account_number
						) 
				values (@UserName
					, @CardType
					, @NameOnCard
					, @AccountNumber
					, @ExpirationMonth
					, @ExpirationYear
					, '0'
					, @@DateOfThisTransaction
					, @BankABACode
					, @BankAccountNumber
					)
			END

		PRINT 'Enter new transaction into transactions_credit_card table'
		INSERT INTO transactions_log (transaction_id
				, batch_transaction_id
				, user_id
				, user_name
				, card_type
				, name_on_card
				, account_number
				, expiration_month
				, expiration_year
				, transaction_type
				, x_response_code
				, months_joined
				, amount
				, date_of_this_transaction
				, date_of_next_transaction
				, x_response_reason_text
				, x_trans_id
				, x_description
				, x_method
				, bank_ABA_code
				, bank_account_number
				) 
		VALUES ( @TransactionID
			, @BatchTransactionID
			, @@UserId
			, @UserName
			, @CardType
			, @NameOnCard
			, @AccountNumber
			, @ExpirationMonth
			, @ExpirationYear
			, @TransactionType
			, '0' -- @XResponseCode
			, @MonthsJoined
			, CONVERT (MONEY, @Amount)
			, @@DateOfThisTransaction
			, @@DateOfNextTransaction
			, 'Waiting for response' -- @XResponseCode
			, @XTransID
			, @XDescription
			, @XMethod
			, @BankABACode
			, @BankAccountNumber
			)
		RETURN 1
		
	END
ELSE
	BEGIN
		PRINT 'ERROR:  User is already a paying member (' + @UserName + '):(' + @@MembershipType + ')'
		RETURN 666
	END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [updateAboutInfo]
@UserName varchar(32)
, @ScreenQuote varchar(128)
, @AboutYourself varchar(3000)
, @Questionable char

 AS

	/* update the about_info table and exit with a return value of 1 */
	
update about_info 
	set user_name =	@UserName
		, screen_quote = @ScreenQuote
		, about_yourself = @AboutYourself
		, questionable = @Questionable
	where user_name = @UserName

return 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [updateBillingInfo]
@UserName		VARCHAR(32)
, @CardType		CHAR(1)
, @NameOnCard	VARCHAR(64)
, @AccountNumber	VARCHAR(32)
, @ExpirationMonth	CHAR(2)
, @ExpirationYear	CHAR(4)
, @BankABACode	 VARCHAR(9)
, @BankAccountNumber VARCHAR(32)

 AS
-- update the user's credit card information in the billing_info table
UPDATE billing_info 
	SET card_type = @CardType
		, name_on_card = @NameOnCard
		, account_number = @AccountNumber
		, expiration_month = @ExpirationMonth
		, expiration_year = @ExpirationYear
		, bank_ABA_code = @BankABACode
		, bank_account_number = @BankAccountNumber
	WHERE user_name = @UserName
RETURN 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [updateBookMarks]
@UserName char(32)
, @Password char(32)
, @BookMark char(32)
, @AddRemove char(8)

 AS

if (@AddRemove = 'Add')
BEGIN
	print 'Add book_mark to book_marks table'
	if exists (select user_name from book_marks where user_name = @UserName AND book_mark = @BookMark)
	BEGIN
		print 'book_mark already exists.'
		return 1
	END
	else
	BEGIN
		print 'book_mark does not exist in book_marks'
			print 'insert user_name and book_mark into the book_marks table'
			insert into book_marks (user_name
					, book_mark
					) 
			values (@UserName
				, @BookMark
				)
		return 1
	END
END
else
if (@AddRemove = 'Remove')
BEGIN
	print 'Remove book_mark from book_marks table'
	DELETE book_marks
		WHERE user_name = @UserName
		AND book_mark = @BookMark
	return 1
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [updateContactInfo]
@UserName varchar(32)
, @FirstName varchar(32)
, @LastName varchar(32)
, @StreetAddress varchar(64)
, @City varchar(32)
, @State varchar(4)
, @Country varchar(4)
, @Zip nchar(5)
, @Telephone varchar(16)

 AS
/* If the user_name is unique add the user to the login_info table and exit with a return value of 1 */
update contact_info 
	set first_name = @FirstName
		, last_name = @LastName
		, street_address = @StreetAddress
		, city = @City
		, state = @State
		, country = @Country
		, zip = @Zip
		, telephone = @Telephone

	where user_name = @UserName
return 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [updateLoginInfo]
@UserId int
, @UserName varchar(32)
, @MembershipType char
, @Password varchar(16)
, @PasswordHint varchar(64)
, @Email varchar(64)
, @Sex char
, @CreationDate varchar(32)
, @LastLogin varchar(32)
, @PhotoSubmitted int -- not used 

 AS
-- UserId must be declared

-- membership_type, creation_date, and last_login must be declared
DECLARE @current_user_name varchar(32)

select @current_user_name = (select user_name from login_info where user_name = @UserName)

if (@current_user_name = @UserName)
BEGIN
	--If the user_name is unique add the user to the login_info table and exit with a return value of 1
	print 'user_name (' + @current_user_name + ')  IS remaining  (' + @UserName
	update login_info 
		set password = @Password
			, password_hint = @PasswordHint
			, email = @Email
			, sex = @Sex
		where user_id = @UserId
	return 1
END
ELSE
	BEGIN
		--Determine if the user_name is unique
		if exists (select user_name from login_info where user_name = @UserName)
		BEGIN
			--If the user_name is not unique exit with a return value of 666
			print 'user_name  is not unique'
			return 666
		END
	ELSE
	BEGIN
		select @current_user_name = (select user_name from login_info where user_id = @UserId)
		--If the user_name is unique add the user to the login_info table and exit with a return value of 1
		print 'user_name (' + @current_user_name + ')  IS unique and being changed to (' + @UserName + ')  in all tables'
		print 'Updating the login_info table'
		update login_info 
			set user_name = @UserName
				, password = @Password
				, password_hint = @PasswordHint
				, email = @Email
				, sex = @Sex
			where user_id = @UserId

		-- Update user_name in all other tables...

		-- Update contact_info table
		print 'Updating the contact_info table'
		update contact_info 
			set user_name = @UserName
			where user_name = @current_user_name

		-- Update personal_info table
		print 'Updating the personal_info table'
		update personal_info 
			set user_name = @UserName
			where user_name = @current_user_name

		-- Update about_info table
		print 'Updating the about_info table'
		update about_info 
			set user_name = @UserName
			where user_name = @current_user_name

		-- Update pictures table
		print 'Updating the pictures table'
		update pictures 
			set user_name = @UserName
			where user_name = @current_user_name

		-- Update relationship table
		print 'Updating the relationship table'
		update relationship 
			set user_name = @UserName
			where user_name = @current_user_name

		-- Update sent_to in mail table
		print 'Updating the sent_to field in the mail table'
		update mail 
			set sent_to = @UserName
			where sent_to = @current_user_name

		-- Update sent_from in mail table
		print 'Updating the sent_from field in the mail table'
		update mail 
			set sent_from = @UserName
			where sent_from = @current_user_name
		return 1
	END
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [updatePersonalInfo]
@UserName varchar(32)
, @SexPreference char
, @Age varchar(4)
, @MaritalStatus varchar(2)
, @Professioin varchar(2)
, @Educatioin varchar(2)
, @Religioin varchar(2)
, @Height varchar(2)
, @Weight varchar(2)
, @Eyes varchar(2)
, @Hair varchar(2)
, @MinAgeDesired varchar(4)
, @MaxAgeDesired varchar(4)
, @Cook varchar(2)
, @Smoke varchar(2)
, @Drink varchar(2)
, @Party varchar(2)
, @Political varchar(2)
, @HousingStatus varchar(2)
, @PreferNotToSay char
, @AnyRelationship char
, @HangOut char
, @ShortTerm char
, @LongTerm char
, @TalkEmail char
, @PhotoExchange char
, @Marriage char
, @Other char

 AS
/* If the user_name is unique update the relationship table and the personal_info table then exit with a return value of 1 */
print 'update relationship table'
update relationship
	set user_name = @UserName
		, prefer_not_to_say = @PreferNotToSay
		, any_relationship = @AnyRelationship
		, hang_out = @HangOut
		, short_term = @ShortTerm
		, long_term = @LongTerm
		, talk_email = @TalkEmail
		, photo_exchange = @PhotoExchange
		, marriage = @Marriage
		, other = @Other
where user_name = @UserName

print 'update personal_info table'
update personal_info 
	set user_name = @UserName
		, age = @Age
		, sex_preference = @SexPreference
		, marital_status = @MaritalStatus
		, profession = @Professioin
		, education = @Educatioin
		, religion = @Religioin
		, height = @Height
		, weight = @Weight
		, eyes = @Eyes
		, hair = @Hair
		, min_age_desired = @MinAgeDesired
		, max_age_desired = @MaxAgeDesired
		, cook = @Cook
		, smoke = @Smoke
		, drink = @Drink
		, party = @Party
		, political = @Political
		, housing_status = @HousingStatus
	where user_name = @UserName
return 1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [updatePicture]
@UserName varchar(32)
, @Password varchar(16)
, @PictureNumber int
, @PictureName varchar(32)

 AS

-- Update the pictures table by adding the new picture_name to the existing user
if exists (select user_name from pictures where user_name = @UserName)
BEGIN
	if ( (select password from login_info where user_name = @UserName) = @Password)
	BEGIN
		if(@PictureNumber = 1)
		BEGIN
			print 'update photo_1 in the pictures table'
			update pictures 
				set photo_1 = @PictureName
				where user_name = @UserName
		END
		else if(@PictureNumber = 2)
		BEGIN
			print 'update photo_2 in the pictures table'
			update pictures 
				set photo_2 = @PictureName
				where user_name = @UserName
		END
		else if(@PictureNumber = 3)
		BEGIN
			print 'update photo_3 in the pictures table'
			update pictures 
				set photo_3 = @PictureName
				where user_name = @UserName
		END
		else if(@PictureNumber = 4)
		BEGIN
			print 'update photo_4 in the pictures table'
			update pictures 
				set photo_4 = @PictureName
				where user_name = @UserName
		END
		else if(@PictureNumber = 5)
		BEGIN
			print 'update photo_5 in the pictures table'
			update pictures 
				set photo_5 = @PictureName
				where user_name = @UserName
		END
		print 'update photo_submitted in the login_info table'
		update login_info 
			set photo_submitted = 1
			where user_name = @UserName
		return 1
	END
	else
	BEGIN
		print 'user_name & password did not match.'
		return 666
	END

END
-- Insert the user_name and picture_name into the pictures table if the user_name does not already exist
else
BEGIN
	print 'user_name does not exist'
	if(@PictureNumber = 1)
	BEGIN
		print 'insert photo_1 in the pictures table'
		insert into pictures (user_name
				, photo_1
				) 
		values (@UserName
			, @PictureName
			)
	END
	else if(@PictureNumber = 2)
	BEGIN
		print 'insert photo_2 in the pictures table'
		insert into pictures (user_name
				, photo_2
				) 
		values (@UserName
			, @PictureName
			)
	END
	else if(@PictureNumber = 3)
	BEGIN
		print 'insert photo_3 in the pictures table'
		insert into pictures (user_name
				, photo_3
				) 
		values (@UserName
			, @PictureName
			)
	END
	else if(@PictureNumber = 4)
	BEGIN
		print 'insert photo_4 in the pictures table'
		insert into pictures (user_name
				, photo_4
				) 
		values (@UserName
			, @PictureName
			)
	END
	else if(@PictureNumber = 5)
	BEGIN
		print 'insert photo_5 in the pictures table'
		insert into pictures (user_name
				, photo_5
				) 
		values (@UserName
			, @PictureName
			)
	END
	print 'update photo_submitted in the login_info table'
	update login_info 
		set photo_submitted = 1
		where user_name = @UserName
	return 1
END

-- clean up all pictures table entries that no longer have pictures...
UPDATE login_info
SET photo_submitted = '0'
WHERE user_name IN ( SELECT login_info.user_name
 FROM login_info
	, pictures
WHERE pictures.user_name = login_info.user_name
AND pictures.photo_1 = 'Nothing'
AND pictures.photo_2 = 'Nothing'
AND pictures.photo_3 = 'Nothing'
AND pictures.photo_4 = 'Nothing'
AND pictures.photo_5 = 'Nothing'
AND login_info.photo_submitted = '1'
)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

