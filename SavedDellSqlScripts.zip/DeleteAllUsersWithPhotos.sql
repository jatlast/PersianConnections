-- START Delete all users with (photo_submitted = 1)...
while (select count(user_name) from login_info where photo_submitted = 1
and user_name != 'jatlast'
and user_name != 'persianconnections') > 0

BEGIN
declare @UserName varchar(32)
select @UserName = (select max(user_name) from login_info where photo_submitted = 1
and user_name != 'jatlast'
and user_name != 'persianconnections')

exec deleteEntireProfileByUserName @UserName
END
-- END Delete all users with (photo_submitted = 1)...

select * from contact_info where country != 0

select * from country


-- START Delete all users with country = 1 (USA)...
while (select count(user_name)from contact_info where country = 1) > 0

BEGIN
declare @UserName varchar(32)
select @UserName = (select max(user_name) from contact_info where country = 1)

exec deleteEntireProfileByUserName @UserName
END
-- END Delete all users with country = 1 (USA)...

select user_name from contact_info where state != 0

select email from login_info order by creation_date

select about_yourself from about_info

-- START Delete all users with country = 0 (Unknown)...
while (select count(user_name)from contact_info where country = 0) > 0

BEGIN
declare @UserName varchar(32)
select @UserName = (select max(user_name) from contact_info where country = 0)

exec deleteEntireProfileByUserName @UserName
END
-- END Delete all users with country = 0 (Unknown)...


-- START Delete all users with state != 0 (Wrong)...
while (select count(user_name)from contact_info where state != 0) > 0

BEGIN
declare @UserName varchar(32)
select @UserName = (select max(user_name) from contact_info where state != 0)

exec deleteEntireProfileByUserName @UserName
END
-- END Delete all users with state != 0 (Wrong)...
