select count(*) as 'Members' from login_info
select count(*) as 'Females' from login_info where sex = 2
select count(*) as 'Females With Photos' from login_info where sex = 2 and photo_submitted = 1
select count(*) as 'Males' from login_info where sex = 1
select count(*) as 'Males With Photos' from login_info where sex = 1 and photo_submitted = 1

--------------- Valid Screen Quot Stats -----------------
declare @UsersWithoutData char(4)
declare @TotatlRealUsers char(4)
declare @UsersWithData char(4)
select @UsersWithoutData = ( select count(*) from about_info where screen_quote like 'User did not enter any text'
and user_name in (select user_name from login_info where password != 'password'))
select @TotatlRealUsers = (select count(*) from login_info where password != 'password')
select @UsersWithData = CONVERT (INT, @TotatlRealUsers) - CONVERT (INT, @UsersWithoutData)
print @TotatlRealUsers +  'REAL users'
print @UsersWithoutData + 'INVALID screen_quote'
print @UsersWithData +    'VALID   screen_quote'
----------END Valid Screen Quot Stats -----------------

select * from login_info where password_hint = 'poury'
select * from login_info where email = 'stevetakesh@hotmail.com'
--update mail set sent_to = 'Anthony' where sent_to = 'Anthony1'
singleProfile 'stevetakesh'
singleProfile 'salaheddin'

--update login_info set photo_submitted = '0' where user_name = 'farzin_f'
--delete login_info where user_name = 'Shaman1'
--createLoginInfo '', 'Shaman', '', 'zippy', 'Shalchi', 'shahin@rmi.net', '1', '', '', '0'
singleProfile 'Anthony'
genmemberhome 'persianconnections', 'janesays'
genmemberhome 'anthony', 'hydro'
select * from login_info where user_name = 'Anthony'
select * from contact_info where user_name like 'Sarvenaz21%'
select * from personal_info where user_name like 'Sarvenaz21%'
select * from about_info where user_name like 'Sarvenaz21%'

--update contact_info set user_name = 'Sarvenaz21' where user_name = 'Nazpari'
--update personal_info set user_name = 'Sarvenaz21' where user_name = 'Nazpari'
--update about_info set user_name = 'Sarvenaz21' where user_name = 'Nazpari'
--update pictures set user_name = 'Sarvenaz21' where user_name = 'Nazpari'
--update relationship set user_name = 'Sarvenaz21' where user_name = 'Nazpari'
--update mail set sent_to = 'Sarvenaz21' where sent_to = 'Nazpari'
--update mail set sent_from = 'Sarvenaz21' where sent_from = 'Nazpari'

select * from mail order by when_read
where sender_deleted = 1 and receiver_deleted = 1 order by mail_id DESC
select * from contact_info where user_name = 'Sarvenaz21'
select * from personal_info where user_name = 'Sarvenaz21'
select * from about_info where user_name = 'Sarvenaz21'
select * from relationship where user_name = 'Sarvenaz21'
select * from mail where sent_to = 'Reza'
select * from mail where sent_from = 'Reza'

--deleteEntireProfileByUserName 'Reza'
select * from login where user_name 
select * from pictures
select * from housing_status

---- Find and delete all mails where both parties deleted their mail
select count(*) from mail 
	where sender_deleted = 1 
		and receiver_deleted = 1
--delete mail where sender_deleted = 1 and receiver_deleted = 1

select * from login_info where user_name like 'Rezwan'

select * from contact_info where first_name like '%kasra%'
select * from login_info where email like 'salahe%'

select * from mail where sent_from != 'persianconnections'
and when_sent > '10/7/2001'
order by when_sent desc
and subject like 'terrorist' or message_text like 'terrorist'

and user_name in (select user_name from login_info where creation_date > '2000-12-16' and creation_date < '2000-12-17' and sex = '1')

select * from login_info where user_name = 'ali57'
--update login_info set sex = 1 where user_name = 'ali57'


select * from mail where
subject like '%fuck%'
or message_text like '%fuck%'
or subject like '%cunt%'
or message_text like '%cunt%'
or subject like '%dick%'
or message_text like '%dick%'

-- Find all new mail...
select mail_id, sent_to, sent_from, when_sent, message_text from mail where sent_to != 'jp' and sent_to != 'persianconnections'
and sent_from != 'jp' and sent_from != 'persianconnections'
order by when_sent DESC

select * from login_info where creation_date > '2000-12-16' and creation_date < '2000-12-17' 
select * from about_info where user_name = 'Nicole16508'

select count(distinct sent_to)as 'Have been mailed' from mail

select count(*)as 'Total Members' from login_info

select count(user_name)as 'Have not been mailed'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 

select count(user_name)as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name not in(select user_name from contact_info where country = 40)
and sex != 2
and creation_date > '2000-12-16' and creation_date < '2000-12-17' 

select * from login_info where user_name = 'homeyra'

singleProfile 'Mehrnoosh'

and m.sent_from != li.user_name


advancedSearch '0', '2', '1', '1', 'hoboken', '35', '1', '0', '0', '0', '18', '35', '12', '26', '3', '21', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'jatlast', '1', '10', 'age', '1'

-- Find all new Female members...
select * from login_info where password != 'password' and sex = 2
order by creation_date DESC

-- Find all new members with photos...
select * from login_info where password != 'password' and photo_submitted = 1
order by creation_date DESC

-- Find all new members...
select * from login_info where password != 'password'
order by creation_date DESC

select * from login_info where user_name like '%rnoo%'
select * from contact_info where user_name = 'Mehrnoosh'
select * from personal_info where user_name = 'Mehrnoosh'
select * from about_info where user_name = 'Mehrnoosh'



--update personal_info set sex_preference = 4 where user_name = 'parisa'

select * from sex_preference

select * from about_info where 
about_yourself like '%lesbian%'
or screen_quote like '%lesbian%'
or about_yourself like '%gay%'
or screen_quote like '%gay%'
or about_yourself like '%pussy%'
or screen_quote like '%pussy%'
or about_yourself like '%asshole%'
or screen_quote like '%asshole%'
or about_yourself like '%cock%'
or screen_quote like '%cock%'
or about_yourself like '%oralsex%'
or screen_quote like '%oralsex%'
or about_yourself like '%oral sex%'
or screen_quote like '%oral sex%'
or about_yourself like '%dick%'
or screen_quote like '%dick%'
or about_yourself like '%suck%'
or screen_quote like '%suck%'
or about_yourself like '%piss%'
or screen_quote like '%piss%'
or about_yourself like '%tits%'
or screen_quote like '%tits%'
or about_yourself like '%penis%'
or screen_quote like '%penis%'

--admin_DeleteEntireProfileByUserName 'stevetakesh'

singleProfile 'shirin'

getPersonalInfoByNamePassword 'Shirin', 'persia'
select * from personal_info where party = 5 
--insert into party (choice, value) values ('I party so hard I wake up in different time zones','5')
--delete party where value = 5

select * from login_info where user_name = 'shirin'
select * from contact_info where user_name = 'shirin'
select * from personal_info where user_name = 'shirin'
select * from about_info where user_name = 'shirin'
select * from relationship where user_name = 'shirin'
select * from pictures where user_name = 'shirin'
select * from mail where sent_to = 'shirin'

--update personal_info set party = 4 where user_name = 'shirin'

select count(user_name)as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name in(select user_name from contact_info where country = 40)
and sex = 2
and creation_date > '2000-12-16' and creation_date < '2000-12-17' 

select * from login_info where sex = 1
and user_name in (select user_name from contact_info where country = 40)
and user_name in (select user_name from about_info where screen_quote like 'User did not enter any text')
declare @Sex int
select @Sex = 2
select count(*) from login_info where sex = @Sex
select * from contact_info where user_name in (select user_name from login_info where sex = @Sex)
order by country 
-- START Delete all users created after I created the Persian Dump...
while (select count(user_name) as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name in(select user_name from contact_info where country = 40)
and sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17' 
) > 500
Begin
declare @UserName varchar(32)
select @UserName = (select max(user_name) as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name in(select user_name from contact_info where country = 40)
and sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17' )
--exec admin_DeleteEntireProfileByUserName @UserName
end
-- END Delete all users created after I created the Persian Dump...

select * from contact_info where country != 40 and country = 1

-- START Delete all users created after I created the Persian Dump...
while (select count(user_name) as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name not in(select user_name from contact_info where city like '%tehran%')
and sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17' 
) > 0
Begin
declare @UserName varchar(32)
select @UserName = (select max(user_name) as 'Ones to remove'
from login_info
where user_name not in(select sent_to from mail) 
and user_name not in(select sent_from from mail) 
and user_name not in(select user_name from contact_info where city like '%tehran%')
and sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17')
--exec admin_DeleteEntireProfileByUserName @UserName
end
-- END Delete all users created after I created the Persian Dump...


select * from login_info where user_name = 'isabela'

-- START Delete all FAKE users...
while (select count(user_name) as 'Ones to remove'
from login_info
where sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17' 
) > 0
Begin
declare @UserName varchar(32)
select @UserName = (select max(user_name) as 'Ones to remove'
from login_info
where sex = 1
and creation_date > '2000-12-16' and creation_date < '2000-12-17')
--exec admin_DeleteEntireProfileByUserName @UserName
end
-- END Delete all FAKE users...

select * from state
select * from country order by choice


select distinct(country) from contact_info

select * from contact_info
where country = '17' order by city

update contact_info set country = '153' 
where country = '6'
and city like 'pyongtaek'
and user_name = 'kamal'

admin_GetDanglingUserNames

--admin_DeleteAllDanglingUserNames

