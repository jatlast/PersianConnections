select state.choice as 'state'
	, count(login_info.user_name) as 'count'
from login_info
	, contact_info
	, state
where login_info.user_name = contact_info.user_name
and contact_info.state = state.value
and login_info.user_name != 'joe'
--and login_info.photo_submitted != '0'
and login_info.user_name != 'persianconnections'
and login_info.user_name != 'connectionsadmin'
and login_info.user_name != 'jp'
group by state.choice
order by count desc

