select database_name, count(*) as count from Advertising..table_access_log
group by database_name

