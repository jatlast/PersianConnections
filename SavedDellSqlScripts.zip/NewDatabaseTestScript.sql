--simplesearch '0', '1', '2', '', '', '', '18', '99', '10', 'creation_date', '1'
--advancedSearch'0', '1', '2', '0', '', '0', '0', '0', '0', '0', '0', '18', '99', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '10', 'creation_date', '1', 'Administrator'
--singleProfile 'test', 'Administrator'
singleProfile 'Administrator', 'Administrator'

--select * from login_info
--select * from contact_info
select * from personal_info
--select * from about_info
--checkUsernamePassword 'Administrator', 'Administrator'
--admin_GetDanglingUserNames 
