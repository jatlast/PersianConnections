SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_admin_AllMailingListData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_admin_AllMailingListData]
GO

CREATE PROCEDURE [sp_admin_AllMailingListData]
@OrderBy CHAR(64)		= '_db_name'
, @AscDesc CHAR(4)		= 'ASC'
, @Limit INT			= 100
, @Index CHAR(6)		= '1'
, @LastSentDate DATETIME	= '1/1/1999'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT ''
PRINT 'Order by ' + @OrderBy  + @AscDesc
PRINT ''

-- If @LastSentDate = '1/1/1999' default to current date
IF (@LastSentDate = '1/1/1999')
BEGIN
	-- use SQL wildcard when searching 
	SELECT @LastSentDate = GETDATE()
END

DECLARE @RowCount INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 1 )

-- count the total number of rows in the login_info table...

-- DECLARE a variable to hold the current result of a CURSOR FETCH...
DECLARE @db_name SYSNAME
DECLARE @count INT
DECLARE @TableToFind VARCHAR(32)
SELECT @TableToFind = 'login_info'

-- DECLARE a READ ONLY CURSOR to cycle through the database names in master.sysdatabases...
DECLARE sysdatabases_cursor CURSOR
FOR
SELECT name 
FROM master..sysdatabases
WHERE name != 'master'
and name != 'model'
and name != 'pubs'
and name != 'tempdb'
and name != 'Northwind'
and name != 'msdb'
and name != 'distribution'
and name != 'Mailing_List'
FOR READ ONLY

-- Create temporary contact_info table
-- to hold the readable data...
CREATE TABLE #MailingListInfo 
(
-- cursor...
_db_name 		SYSNAME		NOT NULL

-- login_info...
, _user_id		CHAR(10)	NOT NULL
, _user_name		VARCHAR(32)	NOT NULL
, _membership_type	INT		NOT NULL
, _password		VARCHAR(16)	NOT NULL
, _password_hint	VARCHAR(32)	NOT NULL
, _email_li		VARCHAR(64)	NOT NULL
, _sex			CHAR(1)		NOT NULL
, _creation_date	DATETIME	NOT NULL
, _last_login		DATETIME	NOT NULL
, _photo_submitted	INT		NULL
, _date_started_paying	DATETIME	NULL

-- mailing_list...
, _email_ml		VARCHAR(64)	NOT NULL
, _name			VARCHAR(64)	NULL
, _origin		VARCHAR(64)	NOT NULL
, _address		VARCHAR(32)	NULL
, _valid		CHAR(3)		NOT NULL
, _which_connections	VARCHAR(32)	NOT NULL
, _date_added		DATETIME	NULL
, _city			VARCHAR(32)	NULL
, _state		VARCHAR(32)	NULL
, _country		VARCHAR(32)	NULL
, _last_sent		DATETIME	NULL
, _became_member	CHAR(3)		NULL

-- dynamic...
, _date_added_minus_creation_date	VARCHAR(5)	NULL
, _last_sent_minus_creation_date	VARCHAR(5)	NULL
)

-- OPEN the CURSOR...
OPEN sysdatabases_cursor
-- Since the OPEN command automatically updates the @@CURSOR_ROWS variable,
-- with the number of rows in the data set, check its contents...
--SELECT @@CURSOR_ROWS -- happens too fast and returns -1
SELECT @count = 0
-- FETCH the first row...
FETCH sysdatabases_cursor INTO @db_name

WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT @count = @count + 1
		EXEC('USE ' + @db_name + '
		IF EXISTS ( SELECT * FROM sysobjects WHERE id = object_id(''' + @TableToFind + ''') )
			BEGIN

				-- BEGIN Retreival...
	
				INSERT INTO #MailingListInfo
					SELECT ''' + @db_name + '''
						, login_info.*
						, Mailing_LIst..mailing_list.*
						, DATEDIFF(DAY, Mailing_LIst..mailing_list.date_added, creation_date)
						, DATEDIFF(DAY, Mailing_LIst..mailing_list.last_sent, creation_date)
					from login_info
						, Mailing_LIst..mailing_list
					where login_info.email = Mailing_LIst..mailing_list.email
	
				PRINT ''---------- '' + ''' + @db_name+ '''
				PRINT ''''
	
				-- END Retreival			
			END
			')

		FETCH sysdatabases_cursor INTO @db_name
	END
IF @@FETCH_STATUS = -1 PRINT 'Found ' + convert(VARCHAR(3), @count) + ' database(s).'
ELSE PRINT 'Processing interrupted due to a fetch failure after finding ' + convert(VARCHAR(3), @count) + ' database(s).'
-- CLOSE the CURSOR...
CLOSE sysdatabases_cursor
-- DEALLOCATE (delete) the CURSOR...
DEALLOCATE sysdatabases_cursor

-- Get the info from the current Temp table...
SET ROWCOUNT @RowCount
EXEC ( 'SELECT * FROM #MailingListInfo
	ORDER BY ' + @OrderBy + @AscDesc
     )
-- Drop the temporary contact_info table
DROP TABLE #MailingListInfo

SELECT email
	, origin
	, valid
	, which_connections
	, last_sent
FROM Mailing_LIst..mailing_list
WHERE Mailing_LIst..mailing_list.valid < 10
AND Mailing_LIst..mailing_list.valid > 1
OR Mailing_LIst..mailing_list.valid < 1

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
