select * from about_info 
where screen_quote like '% @%'
or about_yourself like '% @%'
or about_yourself like '% .com %'
or screen_quote like '% .com %'
or about_yourself like '%www.%'
or screen_quote like '%www.%'
