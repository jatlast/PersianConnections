select origin, count(origin) as 'count' from mailing_list
where origin like 'http://groups.yahoo.com%'
group by origin
