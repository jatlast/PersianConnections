select distinct(valid), count(*) as count
from mailing_list
group by valid
order by valid