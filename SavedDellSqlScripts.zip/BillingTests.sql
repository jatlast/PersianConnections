select * from login_info where user_name = 'persianconnections'
select * from about_info where user_name = 'persianconnections'
select * from billing_info where user_name = 'persianconnections'
select * from transactions_log where user_name = 'persianconnections'
select * from membership_cancellation where user_name = 'persianconnections'

truncate table billing_info
truncate table transactions_log
update login_info set membership_type = 0 where user_name = 'persianconnections'


select * from login_info where user_name = 'jp'
