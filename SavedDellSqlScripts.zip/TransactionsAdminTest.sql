SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_admin_AllDatabasesTransactions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_admin_AllDatabasesTransactions]
GO

CREATE PROCEDURE [sp_admin_AllDatabasesTransactions]
@OrderBy CHAR(64)		= '_db_name'
, @AscDesc CHAR(4)		= 'ASC'
, @Limit INT			= 100
, @Index CHAR(6)		= '1'
, @SearchDate DATETIME		= '1/1/1999'

 AS

-- the SET string provides a slight performance gain for stored procedures
SET NOCOUNT ON

PRINT ''
PRINT 'Order by ' + @OrderBy  + @AscDesc
PRINT ''

-- If @FromDate = '1/1/1999' default to current date
IF (@SearchDate = '1/1/1999')
BEGIN
	-- use SQL wildcard when searching 
	SELECT @SearchDate = GETDATE()
END

DECLARE @RowCount INT -- Used to set the rowcount based on index and limit
SELECT @RowCount = ( @Index + @Limit + 1 )

-- count the total number of rows in the login_info table...

DECLARE @ThisMonthBegin DATETIME
DECLARE @ThisMonthEnd DATETIME
DECLARE @LastMonthBegin DATETIME
DECLARE @LastMonthEnd DATETIME
DECLARE @NextMonthBegin DATETIME
DECLARE @NextMonthEnd DATETIME

SELECT @ThisMonthEnd 	= @SearchDate
SELECT @ThisMonthBegin 	= DATEADD(MONTH, -1, @ThisMonthEnd)

SELECT @LastMonthEnd 	= @ThisMonthBegin
SELECT @LastMonthBegin 	= DATEADD(MONTH, -1, @LastMonthEnd)

SELECT @NextMonthBegin 	= GETDATE()
SELECT @NextMonthEnd 	= DATEADD(MONTH, 1, @NextMonthBegin)

PRINT 'Last Month: ' + CONVERT(CHAR(17), @LastMonthBegin)
PRINT '        To: ' + CONVERT(CHAR(17), @LastMonthEnd)
PRINT 'This Month: ' + CONVERT(CHAR(17), @ThisMonthBegin)
PRINT '        To: ' + CONVERT(CHAR(17), @ThisMonthEnd)
PRINT 'Next Month: ' + CONVERT(CHAR(17), @NextMonthBegin)
PRINT '        To: ' + CONVERT(CHAR(17), @NextMonthEnd)
PRINT ''

-- DECLARE a variable to hold the current result of a CURSOR FETCH...
DECLARE @db_name SYSNAME
DECLARE @count INT
DECLARE @TableToFind VARCHAR(64)
SELECT @TableToFind = 'transactions_log'
--SELECT @TableToFind = 'FM_TaskSet'
-- DECLARE a READ ONLY CURSOR to cycle through the database names in master.sysdatabases...
DECLARE sysdatabases_cursor CURSOR
FOR
SELECT name 
FROM master..sysdatabases
WHERE name != 'master'
and name != 'model'
and name != 'pubs'
and name != 'tempdb'
and name != 'Northwind'
and name != 'msdb'
and name != 'distribution'
and name NOT LIKE 'Mailing%'
FOR READ ONLY

-- Create temporary contact_info table
-- to hold the readable data...
CREATE TABLE #Transaction_Info 
(
_db_name 		SYSNAME		NOT NULL
, _profiles		INT		NULL
, _non_paying		INT		NULL
, _paying		INT		NULL
, _percent_paying	DEC(7,4)	NULL
, _recurring		INT		NULL
, _new			INT		NULL
, _cancelled		INT		NULL
, _percent_cancelled	DEC(7,4)	NULL
, _transactions		INT		NULL
, _captured		SMALLMONEY	NULL
, _refunded		SMALLMONEY	NULL
, _transaction_fee	SMALLMONEY	NULL
, _gross		SMALLMONEY	NULL

, _profiles_last		INT		NULL
, _non_paying_last		INT		NULL
, _paying_last			INT		NULL
, _percent_paying_last		DEC(7,4)	NULL
, _recurring_last		INT		NULL
, _new_last			INT		NULL
, _cancelled_last		INT		NULL
, _percent_cancelled_last	DEC(7,4)	NULL
, _transactions_last		INT		NULL
, _captured_last		SMALLMONEY	NULL
, _refunded_last		SMALLMONEY	NULL
, _transaction_fee_last		SMALLMONEY	NULL
, _gross_last			SMALLMONEY	NULL

, _profiles_this		INT		NULL
, _non_paying_this		INT		NULL
, _paying_this			INT		NULL
, _percent_paying_this		DEC(7,4)	NULL
, _recurring_this		INT		NULL
, _new_this			INT		NULL
, _cancelled_this		INT		NULL
, _percent_cancelled_this	DEC(7,4)	NULL
, _transactions_this		INT		NULL
, _captured_this		SMALLMONEY	NULL
, _refunded_this		SMALLMONEY	NULL
, _transaction_fee_this		SMALLMONEY	NULL
, _gross_this			SMALLMONEY	NULL

, _recurring_next		INT		NULL
, _percent_paying_next		DEC(7,4)	NULL
, _captured_next		SMALLMONEY	NULL
, _transaction_fee_next		SMALLMONEY	NULL
, _gross_next			SMALLMONEY	NULL
)

-- OPEN the CURSOR...
OPEN sysdatabases_cursor
-- Since the OPEN command automatically updates the @@CURSOR_ROWS variable,
-- with the number of rows in the data set, check its contents...
--SELECT @@CURSOR_ROWS -- happens too fast and returns -1
SELECT @count = 0
-- FETCH the first row...
FETCH sysdatabases_cursor INTO @db_name

WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT @count = @count + 1
		EXEC('USE ' + @db_name + '
		IF EXISTS ( SELECT * FROM sysobjects WHERE id = object_id(''' + @TableToFind + ''') )
			BEGIN

			DECLARE @MonthlyMembershipFee SMALLMONEY
			DECLARE @TotalMembers INT
			DECLARE @NumberOfMembersWhoPaid INT
			DECLARE @NumberOfNonPayingMembers INT
			DECLARE @NumberOfPayingMembers INT
			DECLARE @NumberOfRecurring INT
			DECLARE @NumberOfNew INT
			DECLARE @NumberOfCancellations INT
			DECLARE @NumberOfTransactions INT
			DECLARE @TotalAmountAdded SMALLMONEY
			DECLARE @TotalAmountSubtracted SMALLMONEY
			DECLARE @PercentPaying DEC(7,4)
			DECLARE @PercentCancelled DEC(7,4)
			DECLARE @TransactionFee SMALLMONEY
			DECLARE @Gross SMALLMONEY
	
			-- BEGIN Overall Transactions Retreival...
			SELECT @TotalMembers = (SELECT COUNT(*) FROM login_info)
				IF( (SELECT @TotalMembers) IS NULL )
					BEGIN
						SELECT @TotalMembers = 0
					END
			
			SELECT @NumberOfNonPayingMembers = (SELECT COUNT(*) FROM login_info
							      WHERE membership_type != 1
							    )
				IF( (SELECT @NumberOfNonPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfNonPayingMembers = 0
					END
			
			SELECT @NumberOfPayingMembers = (SELECT COUNT(*) FROM login_info
							   WHERE membership_type = 1
							)				
				IF( (SELECT @NumberOfPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfPayingMembers = 0
					END
	
			
			SELECT @NumberOfRecurring = (SELECT COUNT(*) FROM transactions_log
						       WHERE x_response_reason_text = ''This transaction has been approved.''
						         AND transaction_type = ''AUTH_CAPTURE''
							 AND x_description LIKE ''BATCH%''
						    )
				IF( (SELECT @NumberOfRecurring) IS NULL )
					BEGIN
						SELECT @NumberOfRecurring = 0
					END
			
			SELECT @NumberOfNew = (SELECT COUNT(*) FROM transactions_log
					         WHERE x_response_reason_text = ''This transaction has been approved.''
						   AND transaction_type = ''AUTH_CAPTURE''
						   AND x_description NOT LIKE ''BATCH%''
					      )
				IF( (SELECT @NumberOfNew) IS NULL )
					BEGIN
						SELECT @NumberOfNew = 0
					END
			
			SELECT @NumberOfCancellations = (SELECT COUNT(*) FROM login_info
							   WHERE membership_type != 1
							     AND date_started_paying IS NOT NULL
							)
				IF( (SELECT @NumberOfCancellations) IS NULL )
					BEGIN
						SELECT @NumberOfCancellations = 0
					END
			
			SELECT @NumberOfMembersWhoPaid = (SELECT COUNT(*) FROM login_info
							    WHERE date_started_paying IS NOT NULL
							)
				IF( (SELECT @NumberOfMembersWhoPaid) IS NULL )
					BEGIN
						SELECT @NumberOfMembersWhoPaid = 0
					END
			
			SELECT @NumberOfTransactions = (SELECT COUNT(amount) FROM transactions_log
							  WHERE x_response_reason_text = ''This transaction has been approved.''
							)
				IF( (SELECT @NumberOfTransactions) IS NULL )
					BEGIN
						SELECT @NumberOfTransactions = 0
					END
			
			SELECT @TotalAmountAdded = (SELECT SUM(amount) FROM transactions_log
						      WHERE x_response_reason_text = ''This transaction has been approved.''
						        AND transaction_type = ''AUTH_CAPTURE''
						   )
				IF( (SELECT @TotalAmountAdded) IS NULL )
					BEGIN
						SELECT @TotalAmountAdded = 0
					END
				
			SELECT @TotalAmountSubtracted = (SELECT SUM(amount) FROM transactions_log
							   WHERE x_response_reason_text = ''This transaction has been approved.''
							     AND transaction_type = ''CREDIT''
							)
				IF( (SELECT @TotalAmountSubtracted) IS NULL )
					BEGIN
						SELECT @TotalAmountSubtracted = 0
					END
			
			IF(@NumberOfPayingMembers != 0 AND @TotalMembers != 0)
				BEGIN
					SELECT @PercentPaying = ( CONVERT(NUMERIC(38, 8), @NumberOfPayingMembers) / CONVERT(NUMERIC(38, 8), @TotalMembers) * 100 )
						IF( (SELECT @PercentPaying) IS NULL )
							BEGIN
								SELECT @PercentPaying = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentPaying = 0
				END
			
	
			IF(@NumberOfCancellations != 0 AND @NumberOfMembersWhoPaid != 0)
				BEGIN
					SELECT @PercentCancelled = ( CONVERT(NUMERIC(38, 8), @NumberOfCancellations) / CONVERT(NUMERIC(38, 8), @NumberOfMembersWhoPaid) * 100 )
						IF( (SELECT @PercentCancelled) IS NULL )
							BEGIN
								SELECT @PercentCancelled = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentCancelled = 0
				END
	
			SELECT @TransactionFee = ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 )
				IF( (SELECT @TransactionFee) IS NULL )
					BEGIN
						SELECT @TransactionFee = 0
					END
	
			SELECT @Gross = (@TotalAmountAdded - @TotalAmountSubtracted - ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 ) )
				IF( (SELECT @Gross) IS NULL )
					BEGIN
						SELECT @Gross = 0
					END
			
			INSERT INTO #Transaction_Info
					(_db_name
					, _profiles
					, _non_paying
					, _paying
					, _percent_paying
					, _recurring
					, _new
					, _cancelled
					, _percent_cancelled
					, _transactions
					, _captured
					, _refunded
					, _transaction_fee
					, _gross
					
					)
				VALUES
					(''' + @db_name + '''
					, @TotalMembers
					, @NumberOfNonPayingMembers
					, @NumberOfPayingMembers
					, @PercentPaying
					, @NumberOfRecurring
					, @NumberOfNew
					, @NumberOfCancellations
					, @PercentCancelled
					, @NumberOfTransactions
					, @TotalAmountAdded
					, @TotalAmountSubtracted
					, @TransactionFee
					, @Gross
					)

			PRINT ''---------- '' + ''' + @db_name+ '''
			PRINT ''All Profiles...''
			PRINT ''profils 	= '' + CONVERT(VARCHAR(7), @TotalMembers)
			PRINT ''non_paying 	= '' + CONVERT(VARCHAR(7), @NumberOfNonPayingMembers)
			PRINT ''paying 		= '' + CONVERT(VARCHAR(7), @NumberOfPayingMembers)
			PRINT ''percent_paying 	= '' + CONVERT(VARCHAR(8), @PercentPaying)
			PRINT ''recurring 	= '' + CONVERT(VARCHAR(7), @NumberOfRecurring)
			PRINT ''new 		= '' + CONVERT(VARCHAR(7), @NumberOfNew)
			PRINT ''cancel 		= '' + CONVERT(VARCHAR(7), @NumberOfCancellations)
			PRINT ''percent_cancel	= '' + CONVERT(VARCHAR(8), @PercentCancelled)
			PRINT ''transactions 	= '' + CONVERT(VARCHAR(7), @NumberOfTransactions)
			PRINT ''captured	= '' + CONVERT(VARCHAR(7), @TotalAmountAdded)
			PRINT ''refunded	= '' + CONVERT(VARCHAR(7), @TotalAmountSubtracted)
			PRINT ''trans_fee	= '' + CONVERT(VARCHAR(7), @TransactionFee)
			PRINT ''gross		= '' + CONVERT(VARCHAR(7), @Gross)
			PRINT ''''

			-- END Overall Transactions Retreival
			
			-- BEGIN Last Month Transactions Retreival...
			SELECT @TotalMembers = (SELECT COUNT(*) FROM login_info
				      		  WHERE creation_date >= ''' + @LastMonthBegin + '''
						    AND creation_date < ''' + @LastMonthEnd + '''
						)
				IF( (SELECT @TotalMembers) IS NULL )
					BEGIN
						SELECT @TotalMembers = 0
					END
			
			SELECT @NumberOfNonPayingMembers = (SELECT COUNT(*) FROM login_info
							      WHERE membership_type != 1
						      		AND creation_date >= ''' + @LastMonthBegin + '''
								AND creation_date < ''' + @LastMonthEnd + '''
							    )
				IF( (SELECT @NumberOfNonPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfNonPayingMembers = 0
					END
			
			SELECT @NumberOfPayingMembers = (SELECT COUNT(*) FROM login_info
							   WHERE membership_type = 1
						      		AND creation_date >= ''' + @LastMonthBegin + '''
								AND creation_date < ''' + @LastMonthEnd + '''
							)				
				IF( (SELECT @NumberOfPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfPayingMembers = 0
					END
	
			SELECT @NumberOfRecurring = (SELECT COUNT(*) FROM transactions_log
						       WHERE x_response_reason_text = ''This transaction has been approved.''
						         AND transaction_type = ''AUTH_CAPTURE''
							 AND x_description LIKE ''BATCH%''
						      	 AND date_of_this_transaction >= ''' + @LastMonthBegin + '''
							 AND date_of_this_transaction < ''' + @LastMonthEnd + '''
						    )
				IF( (SELECT @NumberOfRecurring) IS NULL )
					BEGIN
						SELECT @NumberOfRecurring = 0
					END
			
			SELECT @NumberOfNew = (SELECT COUNT(*) FROM transactions_log
					         WHERE x_response_reason_text = ''This transaction has been approved.''
						   AND transaction_type = ''AUTH_CAPTURE''
						   AND x_description NOT LIKE ''BATCH%''
					      	   AND date_of_this_transaction >= ''' + @LastMonthBegin + '''
						   AND date_of_this_transaction < ''' + @LastMonthEnd + '''
					      )
				IF( (SELECT @NumberOfNew) IS NULL )
					BEGIN
						SELECT @NumberOfNew = 0
					END
			
			SELECT @NumberOfCancellations = (SELECT COUNT(*) FROM membership_cancellation
							   WHERE date_cancelled >= ''' + @LastMonthBegin + '''
							     AND date_cancelled < ''' + @LastMonthEnd + '''
							)
				IF( (SELECT @NumberOfCancellations) IS NULL )
					BEGIN
						SELECT @NumberOfCancellations = 0
					END
			
			SELECT @NumberOfMembersWhoPaid = (SELECT COUNT(*) FROM login_info
							    WHERE date_started_paying IS NOT NULL
						      	     AND creation_date >= ''' + @LastMonthBegin + '''
							     AND creation_date < ''' + @LastMonthEnd + '''
							)
				IF( (SELECT @NumberOfMembersWhoPaid) IS NULL )
					BEGIN
						SELECT @NumberOfMembersWhoPaid = 0
					END
			
			SELECT @NumberOfTransactions = (SELECT COUNT(amount) FROM transactions_log
							  WHERE x_response_reason_text = ''This transaction has been approved.''
						      	   AND date_of_this_transaction >= ''' + @LastMonthBegin + '''
							   AND date_of_this_transaction < ''' + @LastMonthEnd + '''
							)
				IF( (SELECT @NumberOfTransactions) IS NULL )
					BEGIN
						SELECT @NumberOfTransactions = 0
					END
			
			SELECT @TotalAmountAdded = (SELECT SUM(amount) FROM transactions_log
						      WHERE x_response_reason_text = ''This transaction has been approved.''
						        AND transaction_type = ''AUTH_CAPTURE''
						      	AND date_of_this_transaction >= ''' + @LastMonthBegin + '''
							AND date_of_this_transaction < ''' + @LastMonthEnd + '''
						   )
				IF( (SELECT @TotalAmountAdded) IS NULL )
					BEGIN
						SELECT @TotalAmountAdded = 0
					END
			
			SELECT @TotalAmountSubtracted = (SELECT SUM(amount) FROM transactions_log
							   WHERE x_response_reason_text = ''This transaction has been approved.''
							     AND transaction_type = ''CREDIT''
						      	     AND date_of_this_transaction >= ''' + @LastMonthBegin + '''
							     AND date_of_this_transaction < ''' + @LastMonthEnd + '''
							)
				IF( (SELECT @TotalAmountSubtracted) IS NULL )
					BEGIN
						SELECT @TotalAmountSubtracted = 0
					END
			
			IF(@NumberOfPayingMembers != 0 AND @TotalMembers != 0)
				BEGIN
					SELECT @PercentPaying = ( CONVERT(NUMERIC(38, 8), @NumberOfPayingMembers) / CONVERT(NUMERIC(38, 8), @TotalMembers) * 100 )
						IF( (SELECT @PercentPaying) IS NULL )
							BEGIN
								SELECT @PercentPaying = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentPaying = 0
				END
			
	
			IF(@NumberOfCancellations != 0 AND @NumberOfMembersWhoPaid != 0)
				BEGIN
					SELECT @PercentCancelled = ( CONVERT(NUMERIC(38, 8), @NumberOfCancellations) / CONVERT(NUMERIC(38, 8), @NumberOfMembersWhoPaid) * 100 )
						IF( (SELECT @PercentCancelled) IS NULL )
							BEGIN
								SELECT @PercentCancelled = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentCancelled = 0
				END
	
			SELECT @TransactionFee = ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 )
				IF( (SELECT @TransactionFee) IS NULL )
					BEGIN
						SELECT @TransactionFee = 0
					END
	
			SELECT @Gross = (@TotalAmountAdded - @TotalAmountSubtracted - ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 ) )
				IF( (SELECT @Gross) IS NULL )
					BEGIN
						SELECT @Gross = 0
					END
	
			
			UPDATE #Transaction_Info
					SET _profiles_last = @TotalMembers
					, _non_paying_last = @NumberOfNonPayingMembers
					, _paying_last = @NumberOfPayingMembers
					, _percent_paying_last = @PercentPaying
					, _recurring_last = @NumberOfRecurring
					, _new_last = @NumberOfNew
					, _cancelled_last = @NumberOfCancellations
					, _percent_cancelled_last = @PercentCancelled
					, _transactions_last = @NumberOfTransactions
					, _captured_last = @TotalAmountAdded
					, _refunded_last = @TotalAmountSubtracted
					, _transaction_fee_last = @TransactionFee
					, _gross_last = @Gross
				WHERE _db_name = ''' + @db_name + '''

			PRINT ''---------- '' + ''' + @db_name+ '''
			PRINT ''Last Month...''
			PRINT ''profils 	= '' + CONVERT(VARCHAR(7), @TotalMembers)
			PRINT ''non_paying 	= '' + CONVERT(VARCHAR(7), @NumberOfNonPayingMembers)
			PRINT ''paying 		= '' + CONVERT(VARCHAR(7), @NumberOfPayingMembers)
			PRINT ''percent_paying 	= '' + CONVERT(VARCHAR(8), @PercentPaying)
			PRINT ''recurring 	= '' + CONVERT(VARCHAR(7), @NumberOfRecurring)
			PRINT ''new 		= '' + CONVERT(VARCHAR(7), @NumberOfNew)
			PRINT ''cancel 		= '' + CONVERT(VARCHAR(7), @NumberOfCancellations)
			PRINT ''percent_cancel	= '' + CONVERT(VARCHAR(8), @PercentCancelled)
			PRINT ''transactions 	= '' + CONVERT(VARCHAR(7), @NumberOfTransactions)
			PRINT ''captured	= '' + CONVERT(VARCHAR(7), @TotalAmountAdded)
			PRINT ''refunded	= '' + CONVERT(VARCHAR(7), @TotalAmountSubtracted)
			PRINT ''trans_fee	= '' + CONVERT(VARCHAR(7), @TransactionFee)
			PRINT ''gross		= '' + CONVERT(VARCHAR(7), @Gross)
			PRINT ''''
			
			-- END Last Month Transactions Retreival...
			
			
			-- BEGIN This Month Transactions Retreival...
			SELECT @TotalMembers = (SELECT COUNT(*) FROM login_info
				      		  WHERE creation_date >= ''' + @ThisMonthBegin + '''
						    AND creation_date < ''' + @ThisMonthEnd + '''
						)
				IF( (SELECT @TotalMembers) IS NULL )
					BEGIN
						SELECT @TotalMembers = 0
					END
			
			SELECT @NumberOfNonPayingMembers = (SELECT COUNT(*) FROM login_info
							      WHERE membership_type != 1
						      		AND creation_date >= ''' + @ThisMonthBegin + '''
								AND creation_date < ''' + @ThisMonthEnd + '''
							    )
				IF( (SELECT @NumberOfNonPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfNonPayingMembers = 0
					END
			
			SELECT @NumberOfPayingMembers = (SELECT COUNT(*) FROM login_info
							   WHERE membership_type = 1
						      		AND creation_date >= ''' + @ThisMonthBegin + '''
								AND creation_date < ''' + @ThisMonthEnd + '''
							)				
				IF( (SELECT @NumberOfPayingMembers) IS NULL )
					BEGIN
						SELECT @NumberOfPayingMembers = 0
					END
	
			SELECT @NumberOfRecurring = (SELECT COUNT(*) FROM transactions_log
						       WHERE x_response_reason_text = ''This transaction has been approved.''
						         AND transaction_type = ''AUTH_CAPTURE''
							 AND x_description LIKE ''BATCH%''
						      	 AND date_of_this_transaction >= ''' + @ThisMonthBegin + '''
							 AND date_of_this_transaction < ''' + @ThisMonthEnd + '''
						    )
				IF( (SELECT @NumberOfRecurring) IS NULL )
					BEGIN
						SELECT @NumberOfRecurring = 0
					END
			
			SELECT @NumberOfNew = (SELECT COUNT(*) FROM transactions_log
					         WHERE x_response_reason_text = ''This transaction has been approved.''
						   AND transaction_type = ''AUTH_CAPTURE''
						   AND x_description NOT LIKE ''BATCH%''
					      	   AND date_of_this_transaction >= ''' + @ThisMonthBegin + '''
						   AND date_of_this_transaction < ''' + @ThisMonthEnd + '''
					      )
				IF( (SELECT @NumberOfNew) IS NULL )
					BEGIN
						SELECT @NumberOfNew = 0
					END
			
			SELECT @NumberOfCancellations = (SELECT COUNT(*) FROM membership_cancellation
							   WHERE date_cancelled >= ''' + @ThisMonthBegin + '''
							     AND date_cancelled < ''' + @ThisMonthEnd + '''
							)
				IF( (SELECT @NumberOfCancellations) IS NULL )
					BEGIN
						SELECT @NumberOfCancellations = 0
					END
			
			SELECT @NumberOfMembersWhoPaid = (SELECT COUNT(*) FROM login_info
							    WHERE date_started_paying IS NOT NULL
						      	     AND creation_date >= ''' + @ThisMonthBegin + '''
							     AND creation_date < ''' + @ThisMonthEnd + '''
							)
				IF( (SELECT @NumberOfMembersWhoPaid) IS NULL )
					BEGIN
						SELECT @NumberOfMembersWhoPaid = 0
					END
			
			SELECT @NumberOfTransactions = (SELECT COUNT(amount) FROM transactions_log
							  WHERE x_response_reason_text = ''This transaction has been approved.''
						      	   AND date_of_this_transaction >= ''' + @ThisMonthBegin + '''
							   AND date_of_this_transaction < ''' + @ThisMonthEnd + '''
							)
				IF( (SELECT @NumberOfTransactions) IS NULL )
					BEGIN
						SELECT @NumberOfTransactions = 0
					END
			
			SELECT @TotalAmountAdded = (SELECT SUM(amount) FROM transactions_log
						      WHERE x_response_reason_text = ''This transaction has been approved.''
						        AND transaction_type = ''AUTH_CAPTURE''
						      	AND date_of_this_transaction >= ''' + @ThisMonthBegin + '''
							AND date_of_this_transaction < ''' + @ThisMonthEnd + '''
						   )
				IF( (SELECT @TotalAmountAdded) IS NULL )
					BEGIN
						SELECT @TotalAmountAdded = 0
					END
			
			SELECT @TotalAmountSubtracted = (SELECT SUM(amount) FROM transactions_log
							   WHERE x_response_reason_text = ''This transaction has been approved.''
							     AND transaction_type = ''CREDIT''
						      	     AND date_of_this_transaction >= ''' + @ThisMonthBegin + '''
							     AND date_of_this_transaction < ''' + @ThisMonthEnd + '''
							)
				IF( (SELECT @TotalAmountSubtracted) IS NULL )
					BEGIN
						SELECT @TotalAmountSubtracted = 0
					END
			
			IF(@NumberOfPayingMembers != 0 AND @TotalMembers != 0)
				BEGIN
					SELECT @PercentPaying = ( CONVERT(NUMERIC(38, 8), @NumberOfPayingMembers) / CONVERT(NUMERIC(38, 8), @TotalMembers) * 100 )
						IF( (SELECT @PercentPaying) IS NULL )
							BEGIN
								SELECT @PercentPaying = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentPaying = 0
				END
			
	
			IF(@NumberOfCancellations != 0 AND @NumberOfMembersWhoPaid != 0)
				BEGIN
					SELECT @PercentCancelled = ( CONVERT(NUMERIC(38, 8), @NumberOfCancellations) / CONVERT(NUMERIC(38, 8), @NumberOfMembersWhoPaid) * 100 )
						IF( (SELECT @PercentCancelled) IS NULL )
							BEGIN
								SELECT @PercentCancelled = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentCancelled = 0
				END
	
			SELECT @TransactionFee = ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 )
				IF( (SELECT @TransactionFee) IS NULL )
					BEGIN
						SELECT @TransactionFee = 0
					END
	
			SELECT @Gross = (@TotalAmountAdded - @TotalAmountSubtracted - ( (@TotalAmountAdded + @TotalAmountSubtracted) * .05 ) )
				IF( (SELECT @Gross) IS NULL )
					BEGIN
						SELECT @Gross = 0
					END
	
			
			UPDATE #Transaction_Info
					SET _profiles_this = @TotalMembers
					, _non_paying_this = @NumberOfNonPayingMembers
					, _paying_this = @NumberOfPayingMembers
					, _percent_paying_this = @PercentPaying
					, _recurring_this = @NumberOfRecurring
					, _new_this = @NumberOfNew
					, _cancelled_this = @NumberOfCancellations
					, _percent_cancelled_this = @PercentCancelled
					, _transactions_this = @NumberOfTransactions
					, _captured_this = @TotalAmountAdded
					, _refunded_this = @TotalAmountSubtracted
					, _transaction_fee_this = @TransactionFee
					, _gross_this = @Gross
				WHERE _db_name = ''' + @db_name + '''
	
			PRINT ''---------- '' + ''' + @db_name+ '''
			PRINT ''This Month...''
			PRINT ''profils 	= '' + CONVERT(VARCHAR(7), @TotalMembers)
			PRINT ''non_paying 	= '' + CONVERT(VARCHAR(7), @NumberOfNonPayingMembers)
			PRINT ''paying 		= '' + CONVERT(VARCHAR(7), @NumberOfPayingMembers)
			PRINT ''percent_paying 	= '' + CONVERT(VARCHAR(8), @PercentPaying)
			PRINT ''recurring 	= '' + CONVERT(VARCHAR(7), @NumberOfRecurring)
			PRINT ''new 		= '' + CONVERT(VARCHAR(7), @NumberOfNew)
			PRINT ''cancel 		= '' + CONVERT(VARCHAR(7), @NumberOfCancellations)
			PRINT ''percent_cancel	= '' + CONVERT(VARCHAR(8), @PercentCancelled)
			PRINT ''transactions 	= '' + CONVERT(VARCHAR(7), @NumberOfTransactions)
			PRINT ''captured	= '' + CONVERT(VARCHAR(7), @TotalAmountAdded)
			PRINT ''refunded	= '' + CONVERT(VARCHAR(7), @TotalAmountSubtracted)
			PRINT ''trans_fee	= '' + CONVERT(VARCHAR(7), @TransactionFee)
			PRINT ''gross		= '' + CONVERT(VARCHAR(7), @Gross)
			PRINT ''''
			
			-- END This Month Transactions Retreival...
			
			
			-- BEGIN Next Month Transactions Retreival...
			SELECT @TotalMembers = (SELECT COUNT(*) FROM login_info)
				IF( (SELECT @TotalMembers) IS NULL )
					BEGIN
						SELECT @TotalMembers = 0
					END
			
			SELECT @NumberOfRecurring = (SELECT COUNT(*) FROM recurring_transactions
						       WHERE date_of_next_transaction >= ''' + @NextMonthBegin + '''
							 AND date_of_next_transaction < ''' + @NextMonthEnd + '''
						    )
				IF( (SELECT @NumberOfRecurring) IS NULL )
					BEGIN
						SELECT @NumberOfRecurring = 0
					END
			
			IF(@NumberOfRecurring != 0 AND @TotalMembers != 0)
				BEGIN
					SELECT @PercentPaying = ( CONVERT(NUMERIC(38, 8), @NumberOfRecurring) / CONVERT(NUMERIC(38, 8), @TotalMembers) * 100 )
						IF( (SELECT @PercentPaying) IS NULL )
							BEGIN
								SELECT @PercentPaying = 0
							END
				END
			ELSE
				BEGIN
					SELECT @PercentPaying = 0
				END
			
			SELECT @MonthlyMembershipFee = (SELECT MAX(amount) FROM transactions_log
						       WHERE x_response_reason_text = ''This transaction has been approved.''
						         AND transaction_type = ''AUTH_CAPTURE''
							 AND x_description LIKE ''BATCH%''
						    )
				IF( (SELECT @MonthlyMembershipFee) IS NULL )
					BEGIN
						SELECT @MonthlyMembershipFee = 1
					END

			IF(@NumberOfRecurring != 0 AND @MonthlyMembershipFee != 0)
				BEGIN
					SELECT @TotalAmountAdded = ( CONVERT(NUMERIC(38, 8), @NumberOfRecurring) * CONVERT(NUMERIC(38, 8), @MonthlyMembershipFee) )
						IF( (SELECT @TotalAmountAdded) IS NULL )
							BEGIN
								SELECT @TotalAmountAdded = 0
							END
				END
			ELSE
				BEGIN
					SELECT @TotalAmountAdded = 0
				END
	
			SELECT @TransactionFee = ( (@NumberOfRecurring * @MonthlyMembershipFee) * .05 )
				IF( (SELECT @TransactionFee) IS NULL )
					BEGIN
						SELECT @TransactionFee = 0
					END
	
			SELECT @Gross = ( (@NumberOfRecurring * @MonthlyMembershipFee) - @TransactionFee)
				IF( (SELECT @Gross) IS NULL )
					BEGIN
						SELECT @Gross = 0
					END
	
			
			UPDATE #Transaction_Info
					SET _recurring_next = @NumberOfRecurring
					, _percent_paying_next = @PercentPaying
					, _captured_next = @TotalAmountAdded
					, _transaction_fee_next = @TransactionFee
					, _gross_next = @Gross
				WHERE _db_name = ''' + @db_name + '''
	
			PRINT ''---------- '' + ''' + @db_name+ '''
			PRINT ''Next Month...''
			PRINT ''profils 	= '' + CONVERT(VARCHAR(7), @TotalMembers)
			PRINT ''recurring 	= '' + CONVERT(VARCHAR(7), @NumberOfRecurring)
			PRINT ''monthly 	= '' + CONVERT(VARCHAR(7), @MonthlyMembershipFee)
			PRINT ''percent_paying 	= '' + CONVERT(VARCHAR(8), @PercentPaying)
			PRINT ''trans_fee	= '' + CONVERT(VARCHAR(7), @TransactionFee)
			PRINT ''gross		= '' + CONVERT(VARCHAR(7), @Gross)
			PRINT ''''

			-- END Next Month Transactions Retreival...
		END
		')

		FETCH sysdatabases_cursor INTO @db_name
	END
IF @@FETCH_STATUS = -1 PRINT 'Found ' + convert(VARCHAR(3), @count) + ' database(s).'
ELSE PRINT 'Processing interrupted due to a fetch failure after finding ' + convert(VARCHAR(3), @count) + ' database(s).'
-- CLOSE the CURSOR...
CLOSE sysdatabases_cursor
-- DEALLOCATE (delete) the CURSOR...
DEALLOCATE sysdatabases_cursor

-- Get the info from the current Temp table...
SET ROWCOUNT @RowCount
EXEC ( 'SELECT * FROM #Transaction_Info
	ORDER BY ' + @OrderBy + @AscDesc
     )
-- Drop the temporary contact_info table
DROP TABLE #Transaction_Info
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO