if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[billing_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[billing_info]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[credit_card_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[credit_card_type]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[membership_cancellation]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[membership_cancellation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[membership_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[membership_type]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[transactions_log]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[transactions_log]
GO

CREATE TABLE [dbo].[billing_info] (
	[user_name] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[card_type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[name_on_card] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[account_number] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[expiration_month] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[expiration_year] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[is_membership_active] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[date_membership_expires] [datetime] NULL ,
	[bank_ABA_code] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[bank_account_number] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[credit_card_type] (
	[choice] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[value] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[membership_cancellation] (
	[unique_id] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[user_name] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[email] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[date_started_paying] [datetime] NOT NULL ,
	[date_cancelled] [datetime] NOT NULL ,
	[reason_for_leaving] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[membership_prices] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[website_design] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[suggestions] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[membership_type] (
	[membership_type_id] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[membership_type_name] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[date_promotion_started] [datetime] NULL ,
	[date_promotion_ended] [datetime] NULL ,
	[allow_search_simple] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_search_advanced] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_view_profiles] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_mail_receive] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_mail_read] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_mail_send] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_romance_wizard] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_chat_view] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_chat_use] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allow_view_stats] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[transactions_log] (
	[transaction_id] [char] (52) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[batch_transaction_id] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[user_id] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[user_name] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[card_type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[name_on_card] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[account_number] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[expiration_month] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[expiration_year] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[transaction_type] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[x_response_code] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[months_joined] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[amount] [money] NOT NULL ,
	[date_of_this_transaction] [datetime] NOT NULL ,
	[date_of_next_transaction] [datetime] NOT NULL ,
	[x_response_subcode] [char] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_response_reason_code] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_response_reason_text] [varchar] (320) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_auth_code] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_avs_code] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_trans_id] [char] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_md5_hash] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_description] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[x_method] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[bank_ABA_code] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[bank_account_number] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

