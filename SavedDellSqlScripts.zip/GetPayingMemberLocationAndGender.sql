select country.choice as 'country'
	, count(login_info.user_name) as 'count'
from login_info
	, contact_info
	, country
where login_info.membership_type = 1
and login_info.user_name = contact_info.user_name
and contact_info.country = country.value
and login_info.user_name != 'joe'
and login_info.user_name != 'persianconnections'
and login_info.user_name != 'connectionsadmin'
and login_info.user_name != 'jp'
group by country.choice

select login_info.user_name
	, sex.choice
	, contact_info.city
	, state.choice as 'state'
	, country.choice as 'country'
from login_info
	, contact_info
	, state
	, country
	, sex
where login_info.membership_type = 1
and login_info.user_name = contact_info.user_name
and contact_info.state = state.value
and contact_info.country = country.value
and login_info.sex = sex.value
and login_info.user_name != 'joe'
and login_info.user_name != 'persianconnections'
and login_info.user_name != 'connectionsadmin'
and login_info.user_name != 'jp'
order by contact_info.country

