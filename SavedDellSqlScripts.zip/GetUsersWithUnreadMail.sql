SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_admin_GetUsersWithUnreadMail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_admin_GetUsersWithUnreadMail]
GO

CREATE PROCEDURE [sp_admin_GetUsersWithUnreadMail]

AS

	-- the SET string provides a slight performance gain for stored procedures
	SET NOCOUNT ON
	
	-- DECLARE a variable to hold the current result of a CURSOR FETCH...
	DECLARE @db_name SYSNAME
	DECLARE @count INT
	DECLARE @TableToFind VARCHAR(32)
	SELECT @TableToFind = 'login_info'
	
	-- DECLARE a READ ONLY CURSOR to cycle through the database names in master.sysdatabases...
	DECLARE sysdatabases_cursor CURSOR
	FOR
	SELECT name 
	FROM master..sysdatabases
	WHERE name != 'master'
	and name != 'model'
	and name != 'pubs'
	and name != 'tempdb'
	and name != 'Northwind'
	and name != 'msdb'
	and name != 'distribution'
	and name != 'Mailing_List'
	FOR READ ONLY
	
	-- Create temporary contact_info table
	-- to hold the readable data...
	CREATE TABLE #UnreadMailInfo 
	(
		-- mail...
		_sent_to			VARCHAR(32)	NOT NULL
		, _count			INT		NOT NULL
	
		-- cursor...
		, _db_name 			SYSNAME		NOT NULL
		
		-- login_info...
		, _email			VARCHAR(64)	NOT NULL
		, _sex				CHAR(3)		NOT NULL
		, _password			VARCHAR(16)	NOT NULL
		, _days_since_last_login	INT		NOT NULL
	
		-- contact_info...
		, _last_name			VARCHAR(32)	NOT NULL
	)
	
	-- OPEN the CURSOR...
	OPEN sysdatabases_cursor
	-- Since the OPEN command automatically updates the @@CURSOR_ROWS variable,
	-- with the number of rows in the data set, check its contents...
	--SELECT @@CURSOR_ROWS -- happens too fast and returns -1
	SELECT @count = 0
	-- FETCH the first row...
	FETCH sysdatabases_cursor INTO @db_name
	
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SELECT @count = @count + 1
			EXEC('USE ' + @db_name + '
			IF EXISTS ( SELECT * FROM sysobjects WHERE id = object_id(''' + @TableToFind + ''') )
				BEGIN
	
				-- BEGIN Retreival...
	
				INSERT INTO #UnreadMailInfo
					SELECT DISTINCT(sent_to)
						, COUNT(*) AS COUNT
						, ''' + @db_name + '''
						, (SELECT email FROM login_info WHERE user_name = sent_to) AS email
						, (SELECT sex FROM login_info WHERE user_name = sent_to) AS sex
						, (SELECT password FROM login_info WHERE user_name = sent_to) AS email
						, DATEDIFF(DAY, (SELECT last_login FROM login_info WHERE user_name = sent_to), GETDATE()) AS days_since_last_login
						, (SELECT last_name FROM contact_info WHERE user_name = sent_to) AS last_name
					FROM mail
					WHERE when_read IS NULL
					GROUP BY sent_to
	
				PRINT ''---------- '' + ''' + @db_name+ '''
				PRINT ''''
	
				-- END Retreival			
			END
			')
	
			FETCH sysdatabases_cursor INTO @db_name
		END
	IF @@FETCH_STATUS = -1 PRINT 'Found ' + convert(VARCHAR(3), @count) + ' database(s).'
	ELSE PRINT 'Processing interrupted due to a fetch failure after finding ' + convert(VARCHAR(3), @count) + ' database(s).'
	-- CLOSE the CURSOR...
	CLOSE sysdatabases_cursor
	-- DEALLOCATE (delete) the CURSOR...
	DEALLOCATE sysdatabases_cursor
	
	SELECT * FROM #UnreadMailInfo
	
	-- Drop the temporary contact_info table
	DROP TABLE #UnreadMailInfo
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
